# test_jdbc_oracle.py
import sys
import os

def check_jdbc_driver_jar():
    """Проверка существования JAR файла"""
    jar_path = r"appmsw/java/ojdbc6.jar"
    
    if os.path.exists(jar_path):
        print(f"✓ JAR файл найден: {jar_path}")
        print(f"  Размер: {os.path.getsize(jar_path)} байт")
        return True, jar_path
    else:
        print(f"✗ JAR файл НЕ найден: {jar_path}")
        print("  Убедитесь, что файл существует по указанному пути")
        return False, None

def check_jvm_status():
    """Проверка статуса JVM"""
    try:
        import jpype
        if jpype.isJVMStarted():
            print("JVM уже запущена")
            return True
        else:
            print("JVM не запущена")
            return False
    except ImportError:
        print("JPype не установлен")
        return False

def test_jdbc_direct():
    """Прямая проверка JDBC драйвера через JPype"""
    print("\n=== Прямая проверка через JPype ===")
    
    try:
        import jpype
        import jpype.imports
        
        jar_path = r"appmsw/java/ojdbc6.jar"
        
        # Проверяем статус JVM перед запуском
        if jpype.isJVMStarted():
            print("✓ JVM уже запущена")
        else:
            # Запускаем JVM с путем к JAR файлу
            jpype.startJVM(classpath=[jar_path])
            print("✓ JVM успешно запущена")
        
        # Пробуем загрузить класс драйвера
        try:
            from java.lang import Class
            print("Пробуем загрузить класс...")
            
            # Способ 1: Старое имя класса
            driver_class = jpype.JClass('oracle.jdbc.driver.OracleDriver')
            print(f"✓ Класс найден: {driver_class}")
            print(f"  Имя: {driver_class.getName()}")
            
        except Exception as e:
            print(f"✗ Класс 'oracle.jdbc.driver.OracleDriver' не найден: {e}")
            
            # Пробуем новое имя класса
            try:
                driver_class = jpype.JClass('oracle.jdbc.OracleDriver')
                print(f"✓ Класс найден с альтернативным именем: {driver_class}")
                print(f"  Имя: {driver_class.getName()}")
            except Exception as e2:
                print(f"✗ Альтернативный класс также не найден: {e2}")
                
                # Пробуем найти класс динамически
                print("\nПопытка найти класс в classpath...")
                from java.net import URL, URLClassLoader
                from java.io import File
                from java.lang import ClassLoader
                
                # Создаем URL для JAR файла
                jar_url = File(jar_path).toURI().toURL()
                urls = jpype.JArray(URL)([jar_url])
                class_loader = URLClassLoader(urls)
                
                # Пробуем загрузить класс
                try:
                    loaded_class = class_loader.loadClass('oracle.jdbc.driver.OracleDriver')
                    print(f"✓ Класс загружен через URLClassLoader: {loaded_class}")
                except Exception as e3:
                    print(f"✗ Не удалось загрузить класс: {e3}")
                    
                    # Посмотрим что есть в JAR
                    print("\nСодержимое JAR файла (первые 20 классов):")
                    from java.util.jar import JarFile
                    jar = JarFile(jar_path)
                    entries = jar.entries()
                    count = 0
                    while entries.hasMoreElements() and count < 20:
                        entry = entries.nextElement()
                        if entry.getName().endswith('.class'):
                            print(f"  {entry.getName()}")
                            count += 1
                    jar.close()
        
        # НЕ ЗАКРЫВАЕМ JVM здесь, если будем использовать дальше
        # jpype.shutdownJVM()
        return True
        
    except Exception as e:
        print(f"✗ Ошибка при работе с JPype: {e}")
        import traceback
        traceback.print_exc()
        return False

def test_jdbc_connection(jar_path):
    """Тест подключения через JDBC"""
    print("\n=== Тест подключения через JDBC ===")
    
    try:
        import jaydebeapi
        import jpype
        
        # jdbc_url = "jdbc:oracle:thin:@localhost:1521:EBS"
        # username = "user"
        # password = "your_password"  # Замените на реальный пароль
        
        jdbc_url = "jdbc:oracle:thin:@(DESCRIPTION =   (ADDRESS = (PROTOCOL = TCP)(HOST = hr7-scan1.mvk.ru)(PORT = 1521))  (CONNECT_DATA =        (SERVER = DEDICATED)        (SERVICE_NAME = EBSDEV)      )    )"
        username = "is_kip"
        password = "is_kip"  # Замените на реальный пароль

        print(f"JDBC URL: {jdbc_url}")
        print(f"Username: {username}")
        print(f"JAR path: {jar_path}")
        
        # Проверяем статус JVM
        if jpype.isJVMStarted():
            print("✓ Используем уже запущенную JVM")
        else:
            # Запускаем JVM если она не запущена
            jpype.startJVM(classpath=[jar_path])
            print("✓ JVM успешно запущена")
        
        # Пробуем разные имена драйверов
        driver_names = [
            'oracle.jdbc.driver.OracleDriver',  # Старое имя
            'oracle.jdbc.OracleDriver',         # Новое имя
        ]
        
        working_driver = None
        connection_success = False
        
        for driver_name in driver_names:
            try:
                print(f"\nПробуем драйвер: {driver_name}")
                
                # Проверяем доступность класса
                try:
                    driver_class = jpype.JClass(driver_name)
                    print(f"  Класс найден: {driver_class.getName()}")
                except Exception as e:
                    print(f"  ✗ Класс не найден: {str(e)[:100]}...")
                    continue
                
                # Пробуем подключиться
                print("  Пробуем подключиться к БД...")
                conn = jaydebeapi.connect(
                    driver_name,
                    jdbc_url,
                    [username, password],
                    jar_path
                )
                
                print("  ✓ Подключение успешно!")
                working_driver = driver_name
                connection_success = True
                
                # Выполняем тестовый запрос
                cursor = conn.cursor()
                cursor.execute("SELECT 'JDBC Test OK' FROM dual")
                result = cursor.fetchone()
                print(f"  ✓ Результат запроса: {result[0]}")
                
                # Получаем версию БД
                try:
                    cursor.execute("SELECT * FROM v$version WHERE banner LIKE 'Oracle%'")
                    version = cursor.fetchone()
                    if version:
                        print(f"  ✓ Версия Oracle: {version[0]}")
                except:
                    print("  ⚠ Не удалось получить версию Oracle")
                
                cursor.close()
                conn.close()
                break
                
            except Exception as e:
                print(f"  ✗ Ошибка подключения: {str(e)[:100]}...")
                continue
        
        if connection_success:
            print(f"\n✓ Успешно! Рабочий драйвер: {working_driver}")
            return True
        else:
            print("\n✗ Ни один драйвер не сработал")
            return False
            
    except Exception as e:
        print(f"✗ Общая ошибка: {e}")
        import traceback
        traceback.print_exc()
        return False

def cleanup_jvm():
    """Завершение работы JVM"""
    try:
        import jpype
        if jpype.isJVMStarted():
            jpype.shutdownJVM()
            print("✓ JVM завершена")
    except:
        pass

def main():
    print("=== Тестирование Oracle JDBC драйвера из Python ===\n")
    
    try:
        # 1. Проверяем JAR файл
        jar_found, jar_path = check_jdbc_driver_jar()
        if not jar_found:
            print("\n✗ JAR файл не найден. Тестирование невозможно.")
            return
        
        # 2. Проверяем статус JVM перед началом
        check_jvm_status()
        
        # 3. Проверяем драйвер
        direct_test_result = test_jdbc_direct()
        
        # 4. Тест подключения (раскомментируйте для реального теста)
        if direct_test_result:
            print("\n" + "="*50)
            print("Переходим к тесту подключения...")
            
            # Завершаем предыдущую JVM если была запущена
            cleanup_jvm()
            
            # Запускаем тест подключения
            connection_test_result = test_jdbc_connection(jar_path)
        else:
            print("\n✗ Прямая проверка драйвера не удалась")
            connection_test_result = False
        
        print("\n=== Итоги тестирования ===")
        print(f"Прямая проверка драйвера: {'УСПЕШНО' if direct_test_result else 'НЕУДАЧА'}")
        print(f"Тест подключения к БД: {'УСПЕШНО' if connection_test_result else 'НЕУДАЧА'}")
        
    finally:
        # Всегда завершаем JVM в конце
        cleanup_jvm()
    
    print("\n=== Рекомендации ===")
    print("1. Убедитесь, что Oracle слушает на localhost:1521")
    print("2. Проверьте пароль пользователя")
    print("3. Попробуйте скачать новую версию драйвера:")
    print("   - ojdbc8.jar для Java 8+")
    print("   - ojdbc11.jar для Java 11+")
    print("4. Попробуйте альтернативную строку подключения:")
    print("   jdbc:oracle:thin:@//localhost:1521/EBS")
    print("5. Для отладки можно использовать упрощенный тест:")
    print("   - Запустить только test_jdbc_direct()")
    print("   - Или только test_jdbc_connection()")

if __name__ == "__main__":
    main()