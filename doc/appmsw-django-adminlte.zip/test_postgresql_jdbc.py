#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Простой тест JDBC подключения и выполнения запросов к PostgreSQL
"""

import jaydebeapi
import sys
import os

def test_postgresql_jdbc():
    """Тест JDBC подключения к PostgreSQL"""
    print("=" * 80)
    print("ТЕСТ JDBC ПОДКЛЮЧЕНИЯ К POSTGRESQL")
    print("=" * 80)
    
    # Конфигурация подключения (измените под вашу среду) postgresql://172.24.86.249:5434/airflow
    config = {
        'host': '172.24.86.249',
        'port': '5434',
        'database': 'airflow',
        'username': 'airflow',
        'password': 'airflow'
    }
    
    # JAR файлы для PostgreSQL
    postgres_jars = ['appmsw/java/postgresql-42.3.1.jar']
    
    # Формируем JDBC URL
    jdbc_url = f"jdbc:postgresql://{config['host']}:{config['port']}/{config['database']}"
    
    print(f"JDBC URL: {jdbc_url}")
    print(f"Username: {config['username']}")
    print(f"JAR files: {postgres_jars}")
    print()
    
    try:
        # Проверяем наличие JAR файла
        jar_path = postgres_jars[0]
        if not os.path.exists(jar_path):
            print(f"ОШИБКА: JAR файл не найден: {jar_path}")
            return False
        
        print(f"✓ JAR файл найден: {jar_path}")
        
        # Создаем подключение
        print("\nПопытка подключения к PostgreSQL...")
        con = jaydebeapi.connect(
            'org.postgresql.Driver',
            jdbc_url,
            [config['username'], config['password']],
            jars=[postgres_jars]
        )
        
        print("✓ Подключение к PostgreSQL успешно установлено!")
        
        # Выполняем тестовый запрос
        cursor = con.cursor()
        test_query = "SELECT 1 as test_value, 'PostgreSQL JDBC Test' as message"
        
        print(f"\nВыполнение запроса: {test_query}")
        cursor.execute(test_query)
        
        # Получаем результат
        result = cursor.fetchone()
        print(f"✓ Результат: {result}")
        
        # Выполняем запрос к системным таблицам
        system_query = "SELECT version() as postgres_version"
        print(f"\nВыполнение системного запроса: {system_query}")
        cursor.execute(system_query)
        
        version_result = cursor.fetchone()
        print(f"✓ Версия PostgreSQL: {version_result[0][:100]}...")
        
        # Закрываем подключение
        con.close()
        print("\n✓ Подключение закрыто")
        
        return True
        
    except Exception as e:
        print(f"\n❌ Ошибка подключения к PostgreSQL: {str(e)}")
        print("\nВозможные причины:")
        print("1. PostgreSQL сервер не запущен")
        print("2. Неверные параметры подключения")
        print("3. Недостаточные права доступа")
        print("4. JDBC драйвер недоступен")
        return False

def test_postgresql_connection_info():
    """Дополнительная информация о настройке подключения"""
    print("\n" + "=" * 80)
    print("ИНФОРМАЦИЯ О НАСТРОЙКЕ POSTGRESQL JDBC")
    print("=" * 80)
    
    print("Для успешного тестирования настройте следующие параметры:")
    print()
    print("1. PostgreSQL сервер должен быть запущен")
    print("2. Убедитесь, что JDBC драйвер доступен:")
    jar_path = "appmsw/java/postgresql-42.3.1.jar"
    if os.path.exists(jar_path):
        print(f"   ✓ {jar_path}")
    else:
        print(f"   ❌ {jar_path} - файл не найден")
    
    print("\n3. Примеры строк подключения:")
    examples = [
        "jdbc:postgresql://localhost:5432/postgres",
        "jdbc:postgresql://192.168.1.100:5432/mydb", 
        "jdbc:postgresql://localhost:5434/airflow"
    ]
    for example in examples:
        print(f"   {example}")
    
    print("\n4. Требования к пользователю:")
    print("   - Пользователь должен существовать в PostgreSQL")
    print("   - У пользователя должны быть права на подключение")
    print("   - База данных должна существовать")
    
    print("\n5. Команды для проверки PostgreSQL:")
    print("   psql -U postgres -h localhost -p 5432")
    print("   SELECT version();")

def main():
    """Основная функция"""
    print("ТЕСТИРОВАНИЕ JDBC ПОДКЛЮЧЕНИЯ К POSTGRESQL")
    print("Для настройки подключения измените параметры в функции test_postgresql_jdbc()")
    print()
    
    # Проверяем наличие необходимых модулей
    try:
        import jaydebeapi
        print("✓ Модуль jaydebeapi доступен")
    except ImportError:
        print("❌ Модуль jaydebeapi не найден. Установите: pip install jaydebeapi")
        return False
    
    # Показываем информацию о настройке
    test_postgresql_connection_info()
    
    # Запрашиваем подтверждение для тестирования
    print("\n" + "=" * 80)
    response = input("Запустить тест подключения к PostgreSQL? (y/N): ")
    
    if response.lower() in ['y', 'yes', 'да', 'д']:
        success = test_postgresql_jdbc()
        if success:
            print("\n🎉 ТЕСТ POSTGRESQL JDBC УСПЕШНО ЗАВЕРШЕН!")
        else:
            print("\n💥 ТЕСТ POSTGRESQL JDBC НЕ УДАЛСЯ!")
        return success
    else:
        print("\nТест отменен пользователем")
        return None

if __name__ == '__main__':
    main()