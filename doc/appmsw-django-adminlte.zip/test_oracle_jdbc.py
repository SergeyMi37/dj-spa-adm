#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Простой тест JDBC подключения и выполнения запросов к Oracle
"""

import jaydebeapi
import sys
import os

def test_oracle_jdbc():
    """Тест JDBC подключения к Oracle"""
    print("=" * 80)
    print("ТЕСТ JDBC ПОДКЛЮЧЕНИЯ К ORACLE")
    print("=" * 80)
    
    # Конфигурация подключения (измените под вашу среду) 
    # jdbc:oracle:thin:@//hr7-scan1.mvk.ru:1521/EBSDEV
    # jdbc:oracle:thin:@(DESCRIPTION =      (ADDRESS = (PROTOCOL = TCP)(HOST = hr7-scan1.mvk.ru)(PORT = 1521))      (CONNECT_DATA =        (SERVER = DEDICATED)        (SERVICE_NAME = EBSDEV)      )    )
    config = {
        'host': 'hr7-scan1.mvk.ru',
        'port': '1521',
        'service_name': 'EBSDEV',  # или ORCL, или ваш service name
        'username': 'is_kip',
        'password': 'is_kip'
    }
    
    # JAR файлы для Oracle
    oracle_jars = ['appmsw/java/ojdbc6.jar']
    
    # Формируем JDBC URL для Oracle (несколько форматов)
    jdbc_urls = [
        f"jdbc:oracle:thin:@{config['host']}:{config['port']}:{config['service_name']}",
        f"jdbc:oracle:thin:@(DESCRIPTION =   (ADDRESS = (PROTOCOL = TCP)(HOST = hr7-scan1.mvk.ru)(PORT = 1521))  (CONNECT_DATA =        (SERVER = DEDICATED)        (SERVICE_NAME = EBSDEV)      )    )",
        f"jdbc:oracle:thin:@//{config['host']}:{config['port']}/{config['service_name']}"
    ]
    
    print(f"JDBC URLs (попробуем оба):")
    for url in jdbc_urls:
        print(f"  {url}")
    print(f"Username: {config['username']}")
    print(f"JAR files: {oracle_jars}")
    print()
    
    try:
        # Проверяем наличие JAR файла
        jar_path = oracle_jars[0]
        if not os.path.exists(jar_path):
            print(f"ОШИБКА: JAR файл не найден: {jar_path}")
            return False
        
        print(f"✓ JAR файл найден: {jar_path}")
        
        # Пробуем подключиться с разными форматами URL
        connection = None
        for i, jdbc_url in enumerate(jdbc_urls):
            try:
                print(f"\nПопытка {i+1}: {jdbc_url}")
                connection = jaydebeapi.connect(
                    'oracle.jdbc.driver.OracleDriver',
                    jdbc_url,
                    [config['username'], config['password']],
                    jars=[oracle_jars]
                )
                print(f"✓ Подключение к Oracle успешно установлено! (формат {i+1})")
                break
            except Exception as e:
                print(f"❌ Неудача с форматом {i+1}: {str(e)}")
                continue
        
        if connection is None:
            print("❌ Не удалось подключиться ни с одним форматом URL")
            return False
        
        # Выполняем тестовый запрос
        cursor = connection.cursor()
        test_query = "SELECT 1 as test_value, 'Oracle JDBC Test' as message FROM dual"
        
        print(f"\nВыполнение запроса: {test_query}")
        cursor.execute(test_query)
        
        # Получаем результат
        result = cursor.fetchone()
        print(f"✓ Результат: {result}")
        
        # Выполняем запрос к системным представлениям
        system_query = "SELECT banner FROM v$version WHERE rownum = 1"
        print(f"\nВыполнение системного запроса: {system_query}")
        cursor.execute(system_query)
        
        version_result = cursor.fetchone()
        print(f"✓ Версия Oracle: {version_result[0] if version_result else 'Не удалось получить'}")
        
        # Проверяем текущего пользователя
        user_query = "SELECT user FROM dual"
        print(f"\nВыполнение запроса: {user_query}")
        cursor.execute(user_query)
        
        user_result = cursor.fetchone()
        print(f"✓ Текущий пользователь: {user_result[0] if user_result else 'Не удалось получить'}")
        
        # Закрываем подключение
        connection.close()
        print("\n✓ Подключение закрыто")
        
        return True
        
    except Exception as e:
        print(f"\n❌ Ошибка подключения к Oracle: {str(e)}")
        print("\nВозможные причины:")
        print("1. Oracle сервер не запущен")
        print("2. Неверные параметры подключения")
        print("3. Недостаточные права доступа")
        print("4. JDBC драйвер недоступен")
        print("5. Неправильный формат JDBC URL")
        return False

def test_oracle_connection_info():
    """Дополнительная информация о настройке подключения Oracle"""
    print("\n" + "=" * 80)
    print("ИНФОРМАЦИЯ О НАСТРОЙКЕ ORACLE JDBC")
    print("=" * 80)
    
    print("Для успешного тестирования настройте следующие параметры:")
    print()
    print("1. Oracle сервер должен быть запущен")
    print("2. Убедитесь, что JDBC драйвер доступен:")
    jar_path = "appmsw/java/ojdbc6.jar"
    if os.path.exists(jar_path):
        print(f"   ✓ {jar_path}")
    else:
        print(f"   ❌ {jar_path} - файл не найден")
    
    print("\n3. Примеры строк подключения Oracle:")
    examples = [
        "jdbc:oracle:thin:@localhost:1521:XE",
        "jdbc:oracle:thin:@//localhost:1521/ORCL", 
        "jdbc:oracle:thin:@192.168.1.100:1521:ORCL"
    ]
    for example in examples:
        print(f"   {example}")
    
    print("\n4. Форматы JDBC URL для Oracle:")
    print("   a) Традиционный: jdbc:oracle:thin:@host:port:SID")
    print("   b) Сервисный:    jdbc:oracle:thin:@//host:port/service_name")
    
    print("\n5. Требования к пользователю:")
    print("   - Пользователь должен существовать в Oracle")
    print("   - У пользователя должны быть права на подключение")
    print("   - SID или service name должны быть корректными")
    
    print("\n6. Команды для проверки Oracle:")
    print("   sqlplus username/password@localhost:1521/XE")
    print("   SELECT user FROM dual;")

def main():
    """Основная функция"""
    print("ТЕСТИРОВАНИЕ JDBC ПОДКЛЮЧЕНИЯ К ORACLE")
    print("Для настройки подключения измените параметры в функции test_oracle_jdbc()")
    print()
    
    # Проверяем наличие необходимых модулей
    try:
        import jaydebeapi
        print("✓ Модуль jaydebeapi доступен")
    except ImportError:
        print("❌ Модуль jaydebeapi не найден. Установите: pip install jaydebeapi")
        return False
    
    # Показываем информацию о настройке
    test_oracle_connection_info()
    
    # Запрашиваем подтверждение для тестирования
    print("\n" + "=" * 80)
    response = input("Запустить тест подключения к Oracle? (y/N): ")
    
    if response.lower() in ['y', 'yes', 'да', 'д']:
        success = test_oracle_jdbc()
        if success:
            print("\n🎉 ТЕСТ ORACLE JDBC УСПЕШНО ЗАВЕРШЕН!")
        else:
            print("\n💥 ТЕСТ ORACLE JDBC НЕ УДАЛСЯ!")
        return success
    else:
        print("\nТест отменен пользователем")
        return None

if __name__ == '__main__':
    main()