# Исправление ошибки SSL/TLS при подключении к MS SQL Server

## Проблема

При подключении к MS SQL Server через JDBC возникала ошибка:
```
com.microsoft.sqlserver.jdbc.SQLServerException: Драйверу не удалось установить безопасное соединение с SQL Server, используя шифрование SSL. Ошибка: "The server selected protocol version TLS10 is not accepted by client preferences [TLS12]"
```

## Решение

Внесены изменения в файл `home/management/commands/test_mssql_jdbc.py`:

### 1. Изменен JDBC URL

**Было:**
```python
default='jdbc:sqlserver://localhost:1433;databaseName=master'
```

**Стало:**
```python
default='jdbc:sqlserver://localhost:1433;databaseName=master;encrypt=false;trustServerCertificate=true'
```

**Параметры:**
- `encrypt=false` - отключает шифрование соединения
- `trustServerCertificate=true` - доверяет сертификату сервера без проверки

### 2. Добавлены системные свойства Java

Добавлен код для установки системных свойств SSL/TLS:

```python
# Отключение SSL/TLS шифрования
from java.lang import System
System.setProperty("javax.net.ssl.trustStore", "")
System.setProperty("javax.net.ssl.trustStoreType", "Windows-ROOT")
System.setProperty("java.security.enabledAlgorithms", "TLSv1,TLSv1.1,TLSv1.2")
System.setProperty("https.protocols", "TLSv1,TLSv1.1,TLSv1.2")
```

## Результат

После внесения изменений подключение к MS SQL Server работает без ошибок SSL/TLS. Команда успешно выполняется:

```bash
python manage.py test_mssql_jdbc --sql "SELECT @@VERSION"
```

## Альтернативное решение

В проекте также есть файл `test_mssql_jdbc2.py`, который содержит более расширенные настройки для работы с SSL/TLS, включая настройки JVM при запуске.

## Безопасность

⚠️ **Внимание:** Отключение SSL/TLS шифрования делает соединение менее безопасным. Используйте эти настройки только в безопасных сетях или для тестирования. В продакшене рекомендуется настроить правильные сертификаты и протоколы шифрования.