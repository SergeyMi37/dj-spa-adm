# test_jdbc_oracle.py
import sys
import os

def check_jdbc_driver_jar():
    """Проверка существования JAR файла"""
    jar_path = r"appmsw/java/ojdbc6.jar"
    
    if os.path.exists(jar_path):
        print(f"✓ JAR файл найден: {jar_path}")
        print(f"  Размер: {os.path.getsize(jar_path)} байт")
        return True
    else:
        print(f"✗ JAR файл НЕ найден: {jar_path}")
        print("  Убедитесь, что файл существует по указанному пути")
        return False

def test_jdbc_direct():
    """Прямая проверка JDBC драйвера через JPype"""
    print("\n=== Прямая проверка через JPype ===")
    
    try:
        import jpype
        import jpype.imports
        
        jar_path = r"appmsw/java/ojdbc6.jar"
        
        # Запускаем JVM с путем к JAR файлу
        if not jpype.isJVMStarted():
            jpype.startJVM(classpath=[jar_path])
            print("✓ JVM успешно запущена")
        
        # Пробуем загрузить класс драйвера
        try:
            from java.lang import Class
            print("Пробуем загрузить класс...")
            
            # Способ 1: Старое имя класса
            driver_class = jpype.JClass('oracle.jdbc.driver.OracleDriver')
            print(f"✓ Класс найден: {driver_class}")
            print(f"  Имя: {driver_class.getName()}")
            
        except Exception as e:
            print(f"✗ Класс 'oracle.jdbc.driver.OracleDriver' не найден: {e}")
            
            # Пробуем новое имя класса
            try:
                driver_class = jpype.JClass('oracle.jdbc.OracleDriver')
                print(f"✓ Класс найден с альтернативным именем: {driver_class}")
                print(f"  Имя: {driver_class.getName()}")
            except Exception as e2:
                print(f"✗ Альтернативный класс также не найден: {e2}")
                
                # Пробуем найти класс динамически
                print("\nПопытка найти класс в classpath...")
                from java.net import URL, URLClassLoader
                from java.io import File
                from java.lang import ClassLoader
                
                # Создаем URL для JAR файла
                jar_url = File(jar_path).toURI().toURL()
                urls = jpype.JArray(URL)([jar_url])
                class_loader = URLClassLoader(urls)
                
                # Пробуем загрузить класс
                try:
                    loaded_class = class_loader.loadClass('oracle.jdbc.driver.OracleDriver')
                    print(f"✓ Класс загружен через URLClassLoader: {loaded_class}")
                except Exception as e3:
                    print(f"✗ Не удалось загрузить класс: {e3}")
                    
                    # Посмотрим что есть в JAR
                    print("\nСодержимое JAR файла (первые 20 классов):")
                    from java.util.jar import JarFile
                    jar = JarFile(jar_path)
                    entries = jar.entries()
                    count = 0
                    while entries.hasMoreElements() and count < 20:
                        entry = entries.nextElement()
                        if entry.getName().endswith('.class'):
                            print(f"  {entry.getName()}")
                            count += 1
                    jar.close()
        
        jpype.shutdownJVM()
        return True
        
    except Exception as e:
        print(f"✗ Ошибка при работе с JPype: {e}")
        return False

def test_jdbc_connection():
    """Тест подключения через JDBC"""
    print("\n=== Тест подключения через JDBC ===")
    
    try:
        import jaydebeapi
        import jpype
        
        jar_path = r"appmsw/java/ojdbc6.jar"
        jdbc_url = "jdbc:oracle:thin:@(DESCRIPTION =   (ADDRESS = (PROTOCOL = TCP)(HOST = hr7-scan1.mvk.ru)(PORT = 1521))  (CONNECT_DATA =        (SERVER = DEDICATED)        (SERVICE_NAME = EBSDEV)      )    )"
        username = "is_kip"
        password = "is_kip"  # Замените на реальный пароль
        
        print(f"JDBC URL: {jdbc_url}")
        print(f"Username: {username}")
        print(f"JAR path: {jar_path}")
        
        # Сначала проверяем доступность драйвера
        if not jpype.isJVMStarted():
            jpype.startJVM(classpath=[jar_path])
        
        # Пробуем разные имена драйверов
        driver_names = [
            'oracle.jdbc.driver.OracleDriver',  # Старое имя
            'oracle.jdbc.OracleDriver',         # Новое имя
        ]
        
        working_driver = None
        for driver_name in driver_names:
            try:
                print(f"\nПробуем драйвер: {driver_name}")
                # Проверяем доступность класса
                driver_class = jpype.JClass(driver_name)
                print(f"  Класс найден: {driver_class.getName()}")
                
                # Пробуем подключиться
                print("  Пробуем подключиться к БД...")
                conn = jaydebeapi.connect(
                    driver_name,
                    jdbc_url,
                    [username, password],
                    jar_path
                )
                
                print("  ✓ Подключение успешно!")
                working_driver = driver_name
                
                # Выполняем тестовый запрос
                cursor = conn.cursor()
                cursor.execute("SELECT 'JDBC Test OK' FROM dual")
                result = cursor.fetchone()
                print(f"  ✓ Результат запроса: {result[0]}")
                
                # Получаем версию БД
                cursor.execute("SELECT * FROM v$version WHERE banner LIKE 'Oracle%'")
                version = cursor.fetchone()
                if version:
                    print(f"  ✓ Версия Oracle: {version[0]}")
                
                cursor.close()
                conn.close()
                break
                
            except Exception as e:
                print(f"  ✗ Ошибка: {str(e)[:100]}...")
                continue
        
        jpype.shutdownJVM()
        
        if working_driver:
            print(f"\n✓ Успешно! Рабочий драйвер: {working_driver}")
            return True
        else:
            print("\n✗ Ни один драйвер не сработал")
            return False
            
    except Exception as e:
        print(f"✗ Общая ошибка: {e}")
        import traceback
        traceback.print_exc()
        return False

def main():
    print("=== Тестирование Oracle JDBC драйвера из Python ===\n")
    
    # 1. Проверяем JAR файл
    if not check_jdbc_driver_jar():
        print("\n✗ JAR файл не найден. Тестирование невозможно.")
        return
    
    # 2. Проверяем драйвер
    test_jdbc_direct()
    
    # 3. Тест подключения (раскомментируйте для реального теста)
    test_jdbc_connection()
    
    print("\n=== Рекомендации ===")
    print("1. Убедитесь, что Oracle слушает на localhost:1521")
    print("2. Проверьте пароль пользователя")
    print("3. Попробуйте скачать новую версию драйвера:")
    print("   - ojdbc8.jar для Java 8+")
    print("   - ojdbc11.jar для Java 11+")
    print("4. Попробуйте альтернативную строку подключения:")
    print("   jdbc:oracle:thin:@//localhost:1521/EBS")

if __name__ == "__main__":
    main()