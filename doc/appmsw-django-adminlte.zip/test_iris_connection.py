#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Тестовый скрипт для проверки поддержки IRIS JDBC в API подключений к БД
"""
import os
import django
import sys
import json

# Настройка кодировки для вывода
if sys.platform == 'win32':
    import codecs
    sys.stdout = codecs.getwriter('utf-8')(sys.stdout.detach())

# Настройка Django
sys.path.append('e:/repo/a/jdbc/appmsw-django-adminlte')
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'core.settings')
django.setup()

from appmsw.models import DbConnection
from django.contrib.auth.models import User
from appmsw.serializers import DbConnectionSerializer

# Импорты для JDBC тестирования
try:
    import jaydebeapi
    import jaydebeapi as jdb
    JDBC_AVAILABLE = True
except ImportError:
    print("⚠️ JayDeBeApi не установлен, JDBC тесты будут пропущены")
    JDBC_AVAILABLE = False

def test_iris_model():
    """Тест модели DbConnection с IRIS"""
    print("=== Тест модели DbConnection ===")
    
    # Проверяем доступные типы баз данных
    print("Доступные типы баз данных:")
    for db_type, display_name in DbConnection.DATABASE_TYPES:
        print(f"  - {db_type}: {display_name}")
    
    # Проверяем, что IRIS добавлен
    iris_types = [dt for dt, dn in DbConnection.DATABASE_TYPES if dt == 'iris']
    if iris_types:
        print("✅ IRIS успешно добавлен в модель")
    else:
        print("❌ IRIS не найден в модели")
    
    return len(iris_types) > 0

def test_iris_serializer():
    """Тест сериализатора с IRIS"""
    print("\n=== Тест сериализатора ===")
    
    # Создаем тестовые данные
    test_data = {
        'name': 'Test IRIS Connection',
        'database_type': 'iris',
        'connection_string': 'jdbc:IRIS://localhost:1972/SAMPLES',
        'username': 'irisuser',
        'password': 'irispass',
        'description': 'Test IRIS database connection'
    }
    
    serializer = DbConnectionSerializer(data=test_data)
    if serializer.is_valid():
        print("✅ Сериализатор принимает данные с IRIS")
        print("Валидация данных:", serializer.validated_data)
        return True
    else:
        print("❌ Ошибка валидации сериализатора:")
        print(serializer.errors)
        return False

def test_iris_view_logic():
    """Тест логики представления"""
    print("\n=== Тест логики представления ===")
    
    # Проверяем, что database_type IRIS может быть сохранен
    try:
        # Создаем тестового пользователя если его нет
        user, created = User.objects.get_or_create(
            username='testuser',
            defaults={'email': 'test@example.com'}
        )
        if created:
            user.set_password('testpass')
            user.save()
        
        # Создаем тестовое подключение IRIS
        connection = DbConnection.objects.create(
            name='Test IRIS DB',
            database_type='iris',
            connection_string='jdbc:IRIS://localhost:1972/SAMPLES',
            username='irisuser',
            password='irispass',
            description='Test connection',
            user=user
        )
        
        print("✅ Подключение IRIS успешно создано:")
        print(f"  - ID: {connection.id}")
        print(f"  - Название: {connection.name}")
        print(f"  - Тип: {connection.database_type}")
        print(f"  - Строка подключения: {connection.connection_string}")
        
        # Проверяем, что можем получить его через API
        serializer = DbConnectionSerializer(connection)
        api_data = serializer.data
        
        if 'password' in api_data and api_data['password']:
            print("✅ Поле password присутствует в API ответе")
            print(f"  - Password: {api_data['password']}")
        else:
            print("❌ Поле password отсутствует или пустое в API ответе")
        
        # Очистка тестовых данных
        connection.delete()
        user.delete()
        
        return True
        
    except Exception as e:
        print(f"❌ Ошибка при создании подключения IRIS: {e}")
        return False

def test_frontend_integration():
    """Тест интеграции с фронтендом"""
    print("\n=== Тест интеграции с фронтендом ===")
    
    # Проверяем, что все нужные файлы содержат поддержку IRIS
    files_to_check = [
        'appmsw/models.py',
        'spa/src/views/DbQueries.vue',
        'core/views.py'
    ]
    
    iris_references = 0
    for file_path in files_to_check:
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
                if "'iris'" in content or '"iris"' in content or 'iris' in content:
                    iris_references += 1
                    print(f"✅ {file_path}: содержит поддержку IRIS")
                else:
                    print(f"❌ {file_path}: не содержит поддержку IRIS")
        except FileNotFoundError:
            print(f"❌ {file_path}: файл не найден")
    
    return iris_references >= 2

def test_iris_jdbc_connection():
    """Тест реального JDBC подключения к IRIS"""
    print("\n=== Тест JDBC подключения к IRIS ===")
    
    if not JDBC_AVAILABLE:
        print("❌ JayDeBeApi не доступен для тестирования JDBC")
        return False
    
    # Тестовые параметры подключения
    test_configs = [
        {
            'name': 'Локальный IRIS',
            'url': 'jdbc:IRIS://localhost:1972/SAMPLES',
            'username': 'superuser',
            'password': 'SYS'
        },
        {
            'name': 'Локальный IRIS (USER)',
            'url': 'jdbc:IRIS://localhost:1972/USER',
            'username': '_system',
            'password': 'SYS'
        }
    ]
    
    # Поиск доступных JAR файлов
    base_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'appmsw', 'java')
    iris_jars = [
        os.path.join(base_dir, 'intersystems-jdbc-3.7.1.jar'),
        os.path.join(base_dir, 'intersystems-jdbc-3.3.0.jar'),
        os.path.join(base_dir, 'intersystems-jdbc-3.2.0.jar'),
        os.path.join(base_dir, 'intersystems-jdbc-3.1.0.jar')
    ]
    
    available_jars = [jar for jar in iris_jars if os.path.exists(jar)]
    if not available_jars:
        print("❌ Не найдены JAR файлы для IRIS JDBC драйверов")
        print(f"  Поиск в директории: {base_dir}")
        return False
    
    print(f"✅ Найдено {len(available_jars)} JAR файлов:")
    for jar in available_jars:
        print(f"  - {os.path.basename(jar)}")
    
    success_count = 0
    for config in test_configs:
        print(f"\n--- Тестирование: {config['name']} ---")
        print(f"URL: {config['url']}")
        print(f"Username: {config['username']}")
        
        # Пробуем подключиться с каждым доступным JAR
        connection_successful = False
        for jar_path in available_jars:
            try:
                print(f"Попытка подключения с JAR: {os.path.basename(jar_path)}")
                
                # Создаем подключение
                con = jaydebeapi.connect(
                    'com.intersystems.jdbc.IRISDriver',
                    config['url'],
                    [config['username'], config['password']],
                    jars=[jar_path]
                )
                
                # Тестовый запрос
                curs = con.cursor()
                test_query = "SELECT 1 as test_result FROM %SQL.Dummy"
                curs.execute(test_query)
                result = curs.fetchone()
                
                if result and result[0] == 1:
                    print(f"✅ Подключение успешно! JAR: {os.path.basename(jar_path)}")
                    connection_successful = True
                    success_count += 1
                    
                    # Тестируем дополнительный запрос для демонстрации
                    try:
                        demo_query = "SELECT Name, Country FROM %SYS.OSQL.NationalityLanguages WHERE Country LIKE 'R%' ORDER BY Country"
                        curs.execute(demo_query)
                        columns = [col[0] for col in curs.description]
                        rows = curs.fetchall()
                        print(f"  Демо-запрос вернул {len(rows)} строк")
                        print(f"  Колонки: {columns}")
                    except Exception as demo_err:
                        print(f"  Демо-запрос не выполнен: {demo_err}")
                    
                    con.close()
                    break
                else:
                    con.close()
                    print(f"❌ Неожиданный результат тестового запроса")
                    
            except Exception as e:
                print(f"❌ Ошибка подключения с JAR {os.path.basename(jar_path)}: {str(e)}")
                try:
                    if 'con' in locals():
                        con.close()
                except:
                    pass
                continue
        
        if not connection_successful:
            print(f"❌ Не удалось подключиться к {config['name']}")
    
    if success_count > 0:
        print(f"\n✅ JDBC тест пройден: {success_count} из {len(test_configs)} подключений успешны")
        return True
    else:
        print(f"\n❌ JDBC тест не пройден: ни одно подключение не работает")
        print("Возможные причины:")
        print("  - IRIS сервер не запущен")
        print("  - Неверные параметры подключения")
        print("  - Проблемы с сетевым доступом")
        print("  - Несовместимая версия JDBC драйвера")
        return False

def main():
    """Главная функция тестирования"""
    print("Запуск тестирования поддержки IRIS JDBC в DbQueries")
    print("=" * 60)
    
    results = []
    results.append(test_iris_model())
    results.append(test_iris_serializer())
    results.append(test_iris_view_logic())
    results.append(test_frontend_integration())
    
    # Добавляем JDBC тест если доступен
    jdbc_result = test_iris_jdbc_connection()
    results.append(jdbc_result)
    
    print("\n" + "=" * 60)
    print("РЕЗУЛЬТАТЫ ТЕСТИРОВАНИЯ:")
    
    if all(results):
        print("✅ ВСЕ ТЕСТЫ ПРОЙДЕНЫ УСПЕШНО!")
        print("Поддержка IRIS полностью реализована и готова к использованию.")
    else:
        failed_tests = sum(1 for result in results if not result)
        print(f"❌ {failed_tests} тестов(а) не прошли.")
        if not jdbc_result:
            print("⚠️ JDBC тест не пройден - это нормально если нет доступа к IRIS серверу")
    
    print("\nИтоговый статус:")
    print(f"  - Модель данных: {'✅' if results[0] else '❌'}")
    print(f"  - Сериализатор: {'✅' if results[1] else '❌'}")
    print(f"  - Логика представления: {'✅' if results[2] else '❌'}")
    print(f"  - Интеграция фронтенда: {'✅' if results[3] else '❌'}")
    print(f"  - JDBC подключение: {'✅' if results[4] else ('⚠️' if not JDBC_AVAILABLE else '❌')}")
    
    print("\nРекомендации:")
    print("  ✅ Базовая поддержка IRIS реализована в коде")
    print("  🔧 Для полного тестирования необходим доступ к IRIS серверу")
    print("  📝 Используйте формат jdbc:IRIS://host:port/NAMESPACE для подключений")

if __name__ == "__main__":
    main()