#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Test functionality of SPA page and DbQueries component
"""

import os
import sys
import django

# Setup Django
sys.path.append(os.getcwd())
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'core.settings')
django.setup()

from django.test import Client
from django.contrib.auth.models import User
from django.urls import reverse

def test_spa_page():
    """Test SPA page"""
    print("=== SPA PAGE TEST ===")
    
    # Create client
    client = Client()
    
    # Create test user
    if not User.objects.filter(username='testuser').exists():
        user = User.objects.create_user('testuser', 'test@example.com', 'testpass123')
        user.is_staff = True
        user.save()
        print(f"+ Created user: {user.username}")
    
    # Login
    client.login(username='testuser', password='testpass123')
    print("+ User authenticated")
    
    # Test URL
    response = client.get('/my-spa-page/')
    print(f"+ Response status: {response.status_code}")
    print(f"+ Content length: {len(response.content)} bytes")
    
    # Check content
    if b'DbQueries' in response.content:
        print("+ SPA content contains DbQueries component")
    else:
        print("- SPA content missing DbQueries component")
    
    if b'static/spa/assets/' in response.content:
        print("+ SPA content contains static file references")
    else:
        print("- SPA content missing static file references")
    
    return response.status_code == 200 and len(response.content) > 1000

def test_db_queries_api():
    """Test DB queries API endpoint"""
    print("\n=== DB QUERIES API TEST ===")
    
    # Create user
    if not User.objects.filter(username='api_testuser').exists():
        user = User.objects.create_user('api_testuser', 'api@example.com', 'apipass123')
        user.is_staff = True
        user.save()
        print(f"+ Created API user: {user.username}")
    
    # Create client and login
    client = Client()
    client.login(username='api_testuser', password='apipass123')
    
    try:
        # Test GET request first (should not be allowed)
        response_get = client.get('/api/db-queries/')
        print(f"+ GET Response status: {response_get.status_code}")
        
        # Test POST request with SQL query
        test_data = {'query': 'SELECT 1 as test_value'}
        response = client.post('/api/db-queries/', test_data, content_type='application/json')
        print(f"+ POST Response status: {response.status_code}")
        
        if response.status_code == 200:
            data = response.json()
            print(f"+ API Response data: {data}")
            return True
        else:
            print(f"- API Error: {response.content.decode()}")
            return False
    except Exception as e:
        print(f"- API Exception: {e}")
        return False

def test_vue_component():
    """Check Vue component DbQueries"""
    print("\n=== VUE COMPONENT TEST ===")
    
    vue_file = 'spa/src/views/DbQueries.vue'
    if os.path.exists(vue_file):
        with open(vue_file, 'r', encoding='utf-8') as f:
            content = f.read()
            
        checks = [
            ('<template>', 'Template section'),
            ('sqlQuery', 'SQL query property'),
            ('executeQuery', 'executeQuery method'),
            ('/api/db-queries/', 'API endpoint reference'),
            ('data:', 'Data section'),
            ('methods:', 'Methods section'),
            ('mounted()', 'Mounted lifecycle'),
        ]
        
        for pattern, description in checks:
            if pattern in content:
                print(f"+ {description} found")
            else:
                print(f"- {description} missing")
        
        return True
    else:
        print(f"- Vue component file not found: {vue_file}")
        return False

def main():
    """Main testing function"""
    print("Starting SPA functionality testing...\n")
    
    spa_ok = test_spa_page()
    api_ok = test_db_queries_api()
    vue_ok = test_vue_component()
    
    print(f"\n=== TEST RESULTS ===")
    print(f"SPA page: {'PASS' if spa_ok else 'FAIL'}")
    print(f"API endpoint: {'PASS' if api_ok else 'FAIL'}")
    print(f"Vue component: {'PASS' if vue_ok else 'FAIL'}")
    
    if spa_ok and api_ok and vue_ok:
        print("\nALL TESTS PASSED SUCCESSFULLY!")
        print("System ready to work:")
        print("1. Open http://localhost:8000/")
        print("2. Login (adm/adm)")
        print("3. Click 'SPA' in sidebar menu")
        print("4. DB queries form will load automatically")
    else:
        print("\nPROBLEMS DETECTED - additional setup required")

if __name__ == '__main__':
    main()