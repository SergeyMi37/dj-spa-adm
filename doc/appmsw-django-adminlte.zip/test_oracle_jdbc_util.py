#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Тестовый скрипт для проверки работы Oracle JDBC Utility
"""

import sys
import os

# Добавляем путь к Django settings
sys.path.append('.')
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'core.settings')

import django
django.setup()

from appmsw.jdbc_util import OracleJDBCUtil, execute_oracle_query, test_oracle_connection


def test_basic_functionality():
    """Базовый тест функциональности"""
    print("=== Тестирование Oracle JDBC Utility ===\n")
    
    # Настройки подключения
    url = 'jdbc:oracle:thin:@localhost:1521:xe'
    username = 'system'
    password = 'oracle'
    
    # Тест 1: Проверка подключения
    print("1. Тестирование подключения...")
    if test_oracle_connection(url, username, password):
        print("[OK] Подключение к Oracle успешно!")
    else:
        print("[FAIL] Ошибка подключения к Oracle")
        print("   (Это нормально, если Oracle не запущен)")
    
    # Тест 2: Выполнение простого запроса
    print("\n2. Тестирование выполнения запроса...")
    
    # Простой запрос для Oracle
    test_query = "SELECT 1 as test_value FROM DUAL"
    
    try:
        columns, results = execute_oracle_query(url, username, password, test_query)
        
        if results is not None:
            print("[OK] Запрос выполнен успешно!")
            print(f"   Колонки: {columns}")
            print(f"   Результаты: {results}")
        else:
            print("[FAIL] Ошибка выполнения запроса")
            
    except Exception as e:
        print(f"[FAIL] Исключение при выполнении запроса: {e}")
    
    # Тест 3: Тестирование через контекстный менеджер
    print("\n3. Тестирование через контекстный менеджер...")
    
    try:
        with OracleJDBCUtil() as oracle_util:
            if oracle_util.connect(url, username, password):
                print("[OK] Подключение через контекстный менеджер успешно!")
                
                # Выполнение запроса
                results = oracle_util.execute_query(test_query)
                if results:
                    print(f"[OK] Результаты: {results}")
                    columns = oracle_util.get_column_names()
                    if columns:
                        print(f"[OK] Колонки: {columns}")
            else:
                print("[FAIL] Ошибка подключения через контекстный менеджер")
                
    except Exception as e:
        print(f"[FAIL] Исключение при тестировании контекстного менеджера: {e}")
    
    print("\n=== Тестирование завершено ===")


def test_oracle_specific_queries():
    """Тестирование Oracle-специфичных запросов"""
    print("\n=== Тестирование Oracle-специфичных запросов ===\n")
    
    url = 'jdbc:oracle:thin:@localhost:1521:xe'
    username = 'system'
    password = 'oracle'
    
    # Oracle-специфичные запросы для тестирования
    test_queries = [
        ("SELECT SYSDATE FROM DUAL", "Текущая дата Oracle"),
        ("SELECT USER FROM DUAL", "Текущий пользователь"),
        ("SELECT version FROM v$instance", "Версия Oracle"),
        ("SELECT count(*) FROM all_tables WHERE rownum <= 5", "Количество таблиц"),
    ]
    
    for query, description in test_queries:
        print(f"Тест: {description}")
        print(f"Запрос: {query}")
        
        try:
            columns, results = execute_oracle_query(url, username, password, query)
            
            if results is not None and results:
                print(f"[OK] Результат получен:")
                if columns:
                    print(f"   Колонки: {columns}")
                for row in results:
                    print(f"   Строка: {row}")
            else:
                print("[FAIL] Запрос не вернул результатов")
                
        except Exception as e:
            print(f"[FAIL] Ошибка: {e}")
        
        print("-" * 50)


def interactive_test():
    """Интерактивное тестирование"""
    print("\n=== Интерактивное тестирование ===\n")
    
    # Получение настроек подключения от пользователя
    print("Введите настройки подключения к Oracle:")
    url = input("JDBC URL (по умолчанию: jdbc:oracle:thin:@localhost:1521:xe): ").strip()
    if not url:
        url = 'jdbc:oracle:thin:@localhost:1521:xe'
    
    username = input("Имя пользователя (по умолчанию: system): ").strip()
    if not username:
        username = 'system'
    
    password = input("Пароль (по умолчанию: oracle): ").strip()
    if not password:
        password = 'oracle'
    
    print(f"\nНастройки подключения:")
    print(f"URL: {url}")
    print(f"Пользователь: {username}")
    print(f"Пароль: {'*' * len(password)}")
    
    # Тест подключения
    if test_oracle_connection(url, username, password):
        print("\n[OK] Подключение успешно!")
        
        # Интерактивное выполнение запросов
        while True:
            print("\nВведите SQL запрос (или 'quit' для выхода):")
            query = input("SQL> ").strip()
            
            if query.lower() in ['quit', 'exit', 'q']:
                break
            
            if not query:
                continue
            
            try:
                columns, results = execute_oracle_query(url, username, password, query)
                
                if results is not None:
                    print("Результаты:")
                    if columns:
                        print("\t".join(columns))
                        print("-" * 40)
                    
                    for row in results:
                        print("\t".join(str(val) for val in row))
                else:
                    print("Запрос не вернул результатов")
                    
            except Exception as e:
                print(f"Ошибка: {e}")
    else:
        print("\n[FAIL] Не удалось подключиться к Oracle")
        print("   Проверьте настройки подключения и доступность Oracle")


def main():
    """Главная функция"""
    print("Oracle JDBC Utility - Тестовый скрипт")
    print("=" * 40)
    
    if len(sys.argv) > 1:
        if sys.argv[1] == '--interactive' or sys.argv[1] == '-i':
            interactive_test()
        elif sys.argv[1] == '--queries' or sys.argv[1] == '-q':
            test_oracle_specific_queries()
        else:
            print("Использование:")
            print("  python test_oracle_jdbc_util.py          # Базовые тесты")
            print("  python test_oracle_jdbc_util.py -i       # Интерактивное тестирование")
            print("  python test_oracle_jdbc_util.py -q       # Oracle-специфичные тесты")
    else:
        test_basic_functionality()


if __name__ == "__main__":
    main()