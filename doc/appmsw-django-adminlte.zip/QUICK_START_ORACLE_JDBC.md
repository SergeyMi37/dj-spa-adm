# Быстрый старт - Oracle JDBC Utility

## Что создано

1. **`appmsw/jdbc_util.py`** - Основная утилита с классом `OracleJDBCUtil`
2. **`ORACLE_JDBC_UTILITY_DOCUMENTATION.md`** - Подробная документация
3. **`test_oracle_jdbc_util.py`** - Тестовый скрипт

## Быстрое использование

### 1. Простое выполнение запроса

```python
from appmsw.jdbc_util import execute_oracle_query

# Выполнение простого запроса
columns, results = execute_oracle_query(
    url='jdbc:oracle:thin:@localhost:1521:xe',
    username='system',
    password='oracle',
    sql_query='SELECT SYSDATE FROM DUAL'
)

if results:
    print("Колонки:", columns)
    for row in results:
        print("Результат:", row)
```

### 2. Использование через контекстный менеджер

```python
from appmsw.jdbc_util import OracleJDBCUtil

with OracleJDBCUtil() as oracle_util:
    if oracle_util.connect('jdbc:oracle:thin:@localhost:1521:xe', 'system', 'oracle'):
        results = oracle_util.execute_query('SELECT 1 FROM DUAL')
        if results:
            print("Результат:", results)
```

### 3. Тестирование подключения

```python
from appmsw.jdbc_util import test_oracle_connection

if test_oracle_connection('jdbc:oracle:thin:@localhost:1521:xe', 'system', 'oracle'):
    print("Oracle доступен!")
else:
    print("Oracle недоступен")
```

## Тестирование утилиты

```bash
# Базовые тесты
python test_oracle_jdbc_util.py

# Интерактивное тестирование
python test_oracle_jdbc_util.py -i

# Oracle-специфичные тесты
python test_oracle_jdbc_util.py -q
```

## Основные возможности

- ✅ Подключение к Oracle через JDBC
- ✅ Выполнение SELECT запросов
- ✅ Выполнение INSERT/UPDATE/DELETE запросов
- ✅ Получение имен колонок
- ✅ Автоматическое управление ресурсами
- ✅ Обработка ошибок
- ✅ Поддержка контекстного менеджера

## Примеры JDBC URL

```python
# Локальная Oracle XE
url = 'jdbc:oracle:thin:@localhost:1521:xe'

# С Service Name
url = 'jdbc:oracle:thin:@myserver:1521:ORCL'

# С использованием TNS
url = 'jdbc:oracle:thin:@TNS_ALIAS'
```

## Требования

- Oracle JDBC драйвер (ojdbc6.jar или ojdbc8.jar)
- JPype (для запуска Java из Python)
- Django (для интеграции в проект)

## Файлы

- **Основная утилита**: `appmsw/jdbc_util.py`
- **Документация**: `ORACLE_JDBC_UTILITY_DOCUMENTATION.md`
- **Тесты**: `test_oracle_jdbc_util.py`
- **Это руководство**: `QUICK_START_ORACLE_JDBC.md`