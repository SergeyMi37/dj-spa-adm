#!/usr/bin/env python3
"""
Тест исправлений функций тестирования соединений к базам данных
"""

import json
import sys
import os

# Добавляем путь к Django проекту
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

# Настройка Django
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'core.settings')
import django
django.setup()

from core.views import DbQueryAPIView
from django.http import JsonResponse
from django.test import RequestFactory
from django.contrib.auth.models import AnonymousUser, User


class MockRequest:
    """Mock request для тестирования"""
    def __init__(self, data):
        self.data = data
        self.method = 'POST'
        self.path = '/api/db-queries/'

    def get(self, key, default=None):
        return self.data.get(key, default)


def test_invalid_connection_strings():
    """Тест неверных строк подключения"""
    print("🔧 Тестирование валидации строк подключения")
    print("=" * 60)
    
    view = DbQueryAPIView()
    
    # Тестовые данные
    test_cases = [
        {
            'name': 'Пустая строка подключения IRIS',
            'connection': {
                'connectionString': '',
                'username': 'test',
                'password': 'test',
                'database_type': 'iris'
            },
            'expected_error': True
        },
        {
            'name': 'Неверный протокол IRIS',
            'connection': {
                'connectionString': 'http://localhost:1972/USER',
                'username': 'test',
                'password': 'test',
                'database_type': 'iris'
            },
            'expected_error': True
        },
        {
            'name': 'Правильная строка IRIS',
            'connection': {
                'connectionString': 'jdbc:IRIS://localhost:1972/USER',
                'username': 'test',
                'password': 'test',
                'database_type': 'iris'
            },
            'expected_error': False
        },
        {
            'name': 'Строка подключения Oracle с поддержкой разных форматов',
            'connection': {
                'connectionString': 'jdbc:oracle:thin:@localhost:1521:XE',
                'username': 'test',
                'password': 'test',
                'database_type': 'oracle'
            },
            'expected_error': False
        },
        {
            'name': 'Правильная строка PostgreSQL',
            'connection': {
                'connectionString': 'jdbc:postgresql://localhost:5432/testdb',
                'username': 'test',
                'password': 'test',
                'database_type': 'postgresql'
            },
            'expected_error': False
        }
    ]
    
    results = []
    
    for test_case in test_cases:
        print(f"\n📋 {test_case['name']}")
        print(f"   Строка: {test_case['connection']['connectionString']}")
        print(f"   Тип БД: {test_case['connection']['database_type']}")
        
        try:
            # Создаем mock request
            mock_request = MockRequest({
                'testConnection': True,
                'connection': test_case['connection']
            })
            
            # Вызываем метод тестирования
            result = view.test_connection(mock_request)
            
            # Проверяем результат
            if result.status_code == 500:
                error_occurred = True
                error_msg = "Ошибка соединения"
            elif result.status_code == 400:
                error_occurred = True
                error_msg = result.content.decode()
            else:
                error_occurred = False
                error_msg = "Успех"
            
            # Анализируем результат
            expected_error = test_case['expected_error']
            if expected_error and error_occurred:
                status = "✅ ПРАВИЛЬНО - Ошибка ожидалась"
            elif not expected_error and not error_occurred:
                status = "✅ ПРАВИЛЬНО - Успех ожидался"
            elif expected_error and not error_occurred:
                status = "❌ ОШИБКА - Должна была быть ошибка"
            else:
                status = "❌ ОШИБКА - Ошибка не ожидалась"
            
            print(f"   Результат: {status}")
            if error_occurred:
                print(f"   Сообщение: {error_msg}")
            
            results.append({
                'test': test_case['name'],
                'expected_error': expected_error,
                'error_occurred': error_occurred,
                'success': (expected_error and error_occurred) or (not expected_error and not error_occurred),
                'status_code': result.status_code
            })
            
        except Exception as e:
            print(f"   ❌ ИСКЛЮЧЕНИЕ: {str(e)}")
            results.append({
                'test': test_case['name'],
                'expected_error': test_case['expected_error'],
                'error_occurred': True,
                'success': test_case['expected_error'],
                'exception': str(e)
            })
    
    return results


def test_connection_parsing():
    """Тест парсинга строк подключения"""
    print("\n🔧 Тестирование парсинга строк подключения")
    print("=" * 60)
    
    view = DbQueryAPIView()
    
    # Тест извлечения информации о подключении
    test_cases = [
        {
            'connection_string': 'jdbc:IRIS://localhost:1972/USER',
            'expected_host': 'localhost',
            'expected_port': 1972,
            'expected_namespace': 'USER'
        },
        {
            'connection_string': 'jdbc:IRIS://192.168.1.100:1972/SAMPLES',
            'expected_host': '192.168.1.100',
            'expected_port': 1972,
            'expected_namespace': 'SAMPLES'
        },
        {
            'connection_string': 'jdbc:postgresql://localhost:5432/testdb',
            'expected_host': 'localhost',
            'expected_port': 5432
        },
        {
            'connection_string': 'jdbc:oracle:thin:@localhost:1521:XE',
            'expected_host': 'localhost',
            'expected_port': 1521
        }
    ]
    
    for test_case in test_cases:
        print(f"\n📋 {test_case['connection_string']}")
        
        try:
            # Тестируем парсинг для IRIS
            if 'IRIS' in test_case['connection_string']:
                from urllib.parse import urlparse
                o = urlparse(test_case['connection_string'])
                host = o.hostname or 'localhost'
                port = o.port or 1972
                
                # Проверяем результаты
                if host == test_case['expected_host'] and port == test_case['expected_port']:
                    print(f"   ✅ Парсинг хоста и порта: ПРАВИЛЬНО")
                else:
                    print(f"   ❌ Парсинг хоста и порта: ОШИБКА")
                    print(f"      Ожидалось: {test_case['expected_host']}:{test_case['expected_port']}")
                    print(f"      Получено: {host}:{port}")
                
            # Тест для других баз данных
            elif 'postgresql' in test_case['connection_string']:
                from urllib.parse import urlparse
                o = urlparse(test_case['connection_string'].replace('jdbc:', ''))
                host = o.hostname or 'localhost'
                port = o.port or 5432
                
                if host == test_case['expected_host'] and port == test_case['expected_port']:
                    print(f"   ✅ Парсинг PostgreSQL: ПРАВИЛЬНО")
                else:
                    print(f"   ❌ Парсинг PostgreSQL: ОШИБКА")
                    print(f"      Ожидалось: {test_case['expected_host']}:{test_case['expected_port']}")
                    print(f"      Получено: {host}:{port}")
                    
            elif 'oracle' in test_case['connection_string']:
                # Тест ручного парсинга Oracle (упрощенный)
                connection_string = test_case['connection_string']
                if '@' in connection_string:
                    after_at = connection_string.split('@')[1]
                    if ':' in after_at:
                        host_port_db = after_at.split(':')
                        if len(host_port_db) >= 3:
                            host = host_port_db[0] if host_port_db[0] else 'localhost'
                            port = int(host_port_db[1]) if host_port_db[1] else 1521
                            
                            if host == test_case['expected_host'] and port == test_case['expected_port']:
                                print(f"   ✅ Парсинг Oracle: ПРАВИЛЬНО")
                            else:
                                print(f"   ❌ Парсинг Oracle: ОШИБКА")
                                print(f"      Ожидалось: {test_case['expected_host']}:{test_case['expected_port']}")
                                print(f"      Получено: {host}:{port}")
                    
        except Exception as e:
            print(f"   ❌ ИСКЛЮЧЕНИЕ при парсинге: {str(e)}")


def test_error_handling():
    """Тест обработки ошибок"""
    print("\n🔧 Тестирование обработки ошибок")
    print("=" * 60)
    
    view = DbQueryAPIView()
    
    error_test_cases = [
        {
            'name': 'IRIS - Недоступный сервер',
            'connection': {
                'connectionString': 'jdbc:IRIS://nonexistent-server:1972/USER',
                'username': 'test',
                'password': 'test',
                'database_type': 'iris'
            }
        },
        {
            'name': 'PostgreSQL - Неверные креденшелы',
            'connection': {
                'connectionString': 'jdbc:postgresql://localhost:5432/testdb',
                'username': 'invalid_user',
                'password': 'invalid_password',
                'database_type': 'postgresql'
            }
        },
        {
            'name': 'Oracle - Недоступный сервер',
            'connection': {
                'connectionString': 'jdbc:oracle:thin:@nonexistent-server:1521:XE',
                'username': 'test',
                'password': 'test',
                'database_type': 'oracle'
            }
        }
    ]
    
    for test_case in error_test_cases:
        print(f"\n📋 {test_case['name']}")
        
        try:
            mock_request = MockRequest({
                'testConnection': True,
                'connection': test_case['connection']
            })
            
            result = view.test_connection(mock_request)
            
            # Проверяем, что возвращается ошибка
            if result.status_code == 500:
                print(f"   ✅ Правильно возвращена ошибка 500 (серверная ошибка)")
                print(f"   📝 Сообщение будет показано пользователю")
            else:
                print(f"   ❌ Неожиданный статус код: {result.status_code}")
                
        except Exception as e:
            print(f"   ❌ ИСКЛЮЧЕНИЕ: {str(e)}")


def main():
    """Основная функция тестирования"""
    print("🚀 ТЕСТИРОВАНИЕ ИСПРАВЛЕНИЙ ФУНКЦИЙ СОЕДИНЕНИЙ")
    print("=" * 80)
    
    try:
        # Запуск тестов
        validation_results = test_invalid_connection_strings()
        test_connection_parsing()
        test_error_handling()
        
        # Сводка результатов
        print("\n" + "=" * 80)
        print("📊 СВОДКА РЕЗУЛЬТАТОВ")
        print("=" * 80)
        
        successful_tests = sum(1 for r in validation_results if r.get('success', False))
        total_tests = len(validation_results)
        
        print(f"✅ Успешных тестов: {successful_tests} из {total_tests}")
        print(f"📈 Процент успеха: {(successful_tests/total_tests)*100:.1f}%")
        
        if successful_tests == total_tests:
            print("🎉 ВСЕ ТЕСТЫ ПРОЙДЕНЫ УСПЕШНО!")
        else:
            print("⚠️ Некоторые тесты не прошли проверку")
            
            print("\n📋 Детали:")
            for result in validation_results:
                status = "✅" if result.get('success', False) else "❌"
                print(f"   {status} {result['test']}")
        
        return successful_tests == total_tests
        
    except Exception as e:
        print(f"❌ КРИТИЧЕСКАЯ ОШИБКА: {str(e)}")
        return False


if __name__ == '__main__':
    success = main()
    sys.exit(0 if success else 1)