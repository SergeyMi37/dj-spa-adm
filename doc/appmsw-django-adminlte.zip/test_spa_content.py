#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Debug SPA page content
"""

import os
import sys
import django

# Setup Django
sys.path.append(os.getcwd())
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'core.settings')
django.setup()

from django.test import Client
from django.contrib.auth.models import User

# Create client
client = Client()

# Create test user
if not User.objects.filter(username='debuguser').exists():
    user = User.objects.create_user('debuguser', 'debug@example.com', 'debug123')
    user.is_staff = True
    user.save()

# Login
client.login(username='debuguser', password='debug123')

# Test URL
response = client.get('/my-spa-page/')

print("=== SPA PAGE CONTENT DEBUG ===")
print(f"Status: {response.status_code}")
print(f"Content Length: {len(response.content)} bytes")
print(f"Content-Type: {response.get('Content-Type', 'Unknown')}")
print("\n=== RAW CONTENT ===")
content = response.content.decode('utf-8', errors='ignore')
print(repr(content))
print("\n=== HUMAN READABLE CONTENT ===")
print(content)