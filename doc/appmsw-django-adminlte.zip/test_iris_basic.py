#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Базовый тест поддержки IRIS в моделях и API
"""
import os
import django
import sys

# Настройка кодировки для Windows
if sys.platform == 'win32':
    import codecs
    sys.stdout = codecs.getwriter('utf-8')(sys.stdout.detach())

# Настройка Django
sys.path.append('e:/repo/a/jdbc/appmsw-django-adminlte')
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'core.settings')
django.setup()

from appmsw.models import DbConnection
from appmsw.serializers import DbConnectionSerializer

def test_iris_support():
    """Тест поддержки IRIS в базовых компонентах"""
    print("=== Тест базовой поддержки IRIS ===")
    
    # 1. Проверяем модель данных
    print("1. Проверка модели DbConnection:")
    iris_types = [dt for dt, dn in DbConnection.DATABASE_TYPES if dt == 'iris']
    if iris_types:
        print("   ✅ IRIS добавлен в DATABASE_TYPES")
    else:
        print("   ❌ IRIS не найден в DATABASE_TYPES")
        return False
    
    # 2. Проверяем сериализатор
    print("2. Проверка сериализатора:")
    test_data = {
        'name': 'Test IRIS Connection',
        'database_type': 'iris',
        'connection_string': 'jdbc:IRIS://localhost:1972/SAMPLES',
        'username': 'irisuser',
        'password': 'irispass',
        'description': 'Test IRIS database connection'
    }
    
    serializer = DbConnectionSerializer(data=test_data)
    if serializer.is_valid():
        print("   ✅ Сериализатор принимает данные с IRIS")
    else:
        print("   ❌ Ошибка валидации сериализатора:")
        print(f"   {serializer.errors}")
        return False
    
    # 3. Проверяем API views
    print("3. Проверка API views:")
    try:
        from core.views import DbQueryAPIView
        api_view = DbQueryAPIView()
        print("   ✅ DbQueryAPIView импортируется успешно")
        
        # Проверяем наличие методов для IRIS
        methods = [method for method in dir(api_view) if 'iris' in method.lower()]
        if methods:
            print(f"   ✅ Найдены IRIS методы: {methods}")
        else:
            print("   ⚠️ IRIS методы не найдены, но это нормально для базового теста")
    except Exception as e:
        print(f"   ❌ Ошибка импорта API: {e}")
        return False
    
    # 4. Проверяем фронтенд
    print("4. Проверка фронтенда:")
    try:
        with open('spa/src/views/DbQueries.vue', 'r', encoding='utf-8') as f:
            content = f.read()
            if 'iris' in content.lower():
                print("   ✅ Vue компонент содержит поддержку IRIS")
            else:
                print("   ❌ Vue компонент не содержит IRIS")
                return False
    except Exception as e:
        print(f"   ❌ Ошибка чтения Vue компонента: {e}")
        return False
    
    return True

if __name__ == "__main__":
    print("Запуск базового теста поддержки IRIS")
    print("=" * 50)
    
    success = test_iris_support()
    
    print("\n" + "=" * 50)
    if success:
        print("✅ БАЗОВЫЕ ТЕСТЫ ПРОЙДЕНЫ!")
        print("Поддержка IRIS корректно реализована в коде.")
        print("\nДля полного тестирования JDBC подключений:")
        print("1. Установите и настройте IRIS сервер")
        print("2. Запустите полный тест: python test_iris_connection.py")
        print("3. Проверьте подключения через веб-интерфейс")
    else:
        print("❌ БАЗОВЫЕ ТЕСТЫ НЕ ПРОЙДЕНЫ!")
        print("Требуется исправление ошибок.")