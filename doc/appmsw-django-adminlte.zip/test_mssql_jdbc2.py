from django.core.management.base import BaseCommand
import jpype
import jpype.imports
from jpype.types import *

class Command(BaseCommand):
    help = 'Тест выполнения SQL в MS SQL Server по JDBC'

    def add_arguments(self, parser):
        parser.add_argument('--url', type=str, default='jdbc:sqlserver://localhost:1433;databaseName=master;encrypt=false;trustServerCertificate=true;disableSslEncryption=true;sslProtocol=TLSv1.2;loginTimeout=30;socketTimeout=30000;sendStringParametersAsUnicode=false;applicationName=TestApp;integratedSecurity=false;authenticationScheme=JavaKerberos;columnEncryptionSetting=Disabled;serverPreparedStatementDiscardThreshold=10;queryTimeout=30;responseBuffering=adaptive;sendTimeAsDatetime=false;trustStoreType=Windows-ROOT;trustStorePassword=;trustStore=;keyStoreType=Windows-MY;keyStorePassword=;keyStore=;authentication=SqlPassword', help='JDBC URL для подключения к MS SQL Server')
        parser.add_argument('--username', type=str, default='sa', help='Имя пользователя MS SQL Server')
        parser.add_argument('--password', type=str, default='your_password', help='Пароль пользователя MS SQL Server')
        parser.add_argument('--sql', type=str, default='SELECT 1', help='SQL-запрос для выполнения (по умолчанию: SELECT 1)')

    def handle(self, *args, **options):
        # Путь к драйверу MS SQL Server
        jar_path = 'appmsw/java/sqljdbc42.jar'

        # Запуск JVM с указанием пути к драйверу и настройками SSL
        if not jpype.isJVMStarted():
            jpype.startJVM(
                '-Djava.security.properties=',
                '-Djavax.net.ssl.trustStoreType=',
                '-Djavax.net.ssl.trustStore=',
                '-Djavax.net.ssl.trustStorePassword=',
                '-Djavax.net.debug=ssl',
                '-Djava.security.enabledAlgorithms=TLSv1,TLSv1.1,TLSv1.2',
                '-Dhttps.protocols=TLSv1,TLSv1.1,TLSv1.2',
                '-Dcom.microsoft.sqlserver.jdbc.sendTimeAsDatetime=false',
                '-Djava.security.egd=file:/dev/urandom',
                '-Djava.security.debug=all',
                '-Djava.security.auth.login.config=',
                '-Djava.security.krb5.conf=',
                '-Djava.security.krb5.realm=',
                '-Djava.security.krb5.kdc=',
                '-Djava.security.krb5.debug=false',
                '-Djava.security.krb5.useCanonicalHostname=false',
                '-Djava.security.krb5.loginTimeout=30',
                '-Djava.security.krb5.renewTGT=true',
                '-Djava.security.krb5.ticketCache=',
                '-Djava.security.krb5.disableReferrals=true',
                '-Djava.security.krb5.kdcEnabled=true',
                '-Djava.security.krb5.useTicketCache=false',
                '-Djava.security.krb5.useKeyTab=false',
                '-Djava.security.krb5.storeKey=false',
                '-Djava.security.krb5.doNotPrompt=true',
                '-Djava.security.krb5.debug=true',
                '-Djava.security.krb5.debug=true',
                classpath=[jar_path]
            )

        try:
            # Импорт классов JDBC
            from java.sql import DriverManager, SQLException
            from java.lang import Class
            from java.lang import System
            
            # Отключаем SSL
            System.setProperty("javax.net.ssl.trustStore", "")
            System.setProperty("javax.net.ssl.trustStoreType", "Windows-ROOT")
            System.setProperty("com.microsoft.sqlserver.jdbc.sendTimeAsDatetime", "false")
            System.setProperty("java.security.enabledAlgorithms", "TLSv1,TLSv1.1,TLSv1.2")
            System.setProperty("https.protocols", "TLSv1,TLSv1.1,TLSv1.2")

            # Загрузка драйвера MS SQL Server
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver")

            # Подключение к базе данных
            url = options['url']
            username = options['username']
            password = options['password']

            self.stdout.write(f'Подключение к MS SQL Server: {url}')
            conn = DriverManager.getConnection(url, username, password)
            self.stdout.write('Соединение с MS SQL Server установлено')

            # Выполнение указанного SQL-запроса
            sql_query = options['sql']
            self.stdout.write(f'Выполнение запроса: {sql_query}')

            stmt = conn.createStatement()
            rs = stmt.executeQuery(sql_query)

            # Вывод результатов запроса
            columns_count = rs.getMetaData().getColumnCount()
            results_found = False

            while rs.next():
                results_found = True
                row = []
                for i in range(1, columns_count + 1):
                    value = rs.getObject(i)
                    row.append(str(value))
                self.stdout.write('\t'.join(row))

            if not results_found:
                self.stdout.write('Запрос не вернул результатов')

            # Закрытие ресурсов
            rs.close()
            stmt.close()
            conn.close()
            self.stdout.write('Соединение закрыто')

        except Exception as e:
            self.stdout.write(self.style.ERROR(f'Ошибка: {str(e)}'))
        finally:
            # Остановка JVM
            if jpype.isJVMStarted():
                jpype.shutdownJVM()