#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Тест исправлений гибкой валидации строк подключения (без Django)
"""

from urllib.parse import urlparse


def test_flexible_connection_validation():
    """Тест гибкой валидации строк подключения"""
    print("Тестирование гибкой валидации строк подключения")
    print("=" * 60)
    
    test_cases = [
        {
            'name': 'PostgreSQL с jdbc: префиксом',
            'connection_string': 'jdbc:postgresql://localhost:5432/testdb',
            'database_type': 'postgresql',
            'should_pass': True
        },
        {
            'name': 'PostgreSQL без jdbc: префикса (стандартный URL)',
            'connection_string': 'postgresql://172.24.86.249:5434/airflow',
            'database_type': 'postgresql',
            'should_pass': True
        },
        {
            'name': 'PostgreSQL с неправильным протоколом',
            'connection_string': 'mysql://localhost:5432/testdb',
            'database_type': 'postgresql',
            'should_pass': False
        },
        {
            'name': 'IRIS с jdbc:IRIS://',
            'connection_string': 'jdbc:IRIS://localhost:1972/USER',
            'database_type': 'iris',
            'should_pass': True
        },
        {
            'name': 'Oracle с thin driver',
            'connection_string': 'jdbc:oracle:thin:@localhost:1521:XE',
            'database_type': 'oracle',
            'should_pass': True
        },
        {
            'name': 'Oracle без jdbc: префикса',
            'connection_string': 'oracle://localhost:1521:XE',
            'database_type': 'oracle',
            'should_pass': True
        }
    ]
    
    results = []
    
    for test_case in test_cases:
        print(f"\nТест: {test_case['name']}")
        print(f"   Строка: {test_case['connection_string']}")
        print(f"   Тип БД: {test_case['database_type']}")
        
        try:
            connection_string = test_case['connection_string']
            database_type = test_case['database_type']
            should_pass = test_case['should_pass']
            
            # Новая логика валидации
            # Гибкая валидация строки подключения - поддерживаем и обычные URL, и JDBC
            if not connection_string.startswith(('jdbc:', database_type + '://')):
                validation_passed = False
                error_msg = f"Строка подключения должна начинаться с {database_type}:// или jdbc:{database_type}://"
            else:
                validation_passed = True
                error_msg = "Валидация прошла успешно"
                
                # Если строка не начинается с jdbc:, добавляем префикс
                if not connection_string.startswith('jdbc:'):
                    if database_type == 'postgresql':
                        connection_string = 'jdbc:' + connection_string
                        converted_msg = f"Добавлен префикс: {connection_string}"
                    elif database_type == 'oracle':
                        # Oracle требует специальной обработки
                        connection_string = 'jdbc:oracle:thin:' + connection_string
                        converted_msg = f"Добавлен префикс и thin драйвер: {connection_string}"
                    else:
                        connection_string = 'jdbc:' + connection_string
                        converted_msg = f"Добавлен префикс: {connection_string}"
                else:
                    converted_msg = "JDBC URL уже корректен"
            
            # Проверка результатов
            if validation_passed == should_pass:
                status = "[OK] ПРАВИЛЬНО"
                success = True
            else:
                status = "[ERROR] ОШИБКА"
                success = False
            
            print(f"   Результат: {status}")
            print(f"   Валидация: {validation_passed} (ожидалось: {should_pass})")
            print(f"   {error_msg}")
            if validation_passed and 'converted_msg' in locals():
                print(f"   Преобразование: {converted_msg}")
            
            results.append({
                'name': test_case['name'],
                'success': success,
                'validation_passed': validation_passed
            })
            
        except Exception as e:
            print(f"   [ERROR] ИСКЛЮЧЕНИЕ: {str(e)}")
            results.append({
                'name': test_case['name'],
                'success': False,
                'exception': str(e)
            })
    
    return results


def test_postgresql_parsing():
    """Тест парсинга PostgreSQL строк подключения"""
    print("\nТестирование парсинга PostgreSQL")
    print("=" * 60)
    
    test_cases = [
        {
            'original': 'postgresql://172.24.86.249:5434/airflow',
            'expected_jdbc': 'jdbc:postgresql://172.24.86.249:5434/airflow',
            'expected_host': '172.24.86.249',
            'expected_port': 5434,
            'expected_db': 'airflow'
        },
        {
            'original': 'jdbc:postgresql://localhost:5432/mydb',
            'expected_jdbc': 'jdbc:postgresql://localhost:5432/mydb',
            'expected_host': 'localhost',
            'expected_port': 5432,
            'expected_db': 'mydb'
        }
    ]
    
    for test_case in test_cases:
        print(f"\nТест: {test_case['original']}")
        
        # Симуляция преобразования
        connection_string = test_case['original']
        if not connection_string.startswith('jdbc:'):
            connection_string = 'jdbc:' + connection_string
        
        print(f"   Преобразовано в: {connection_string}")
        
        # Парсинг
        try:
            parsed_url = urlparse(connection_string.replace('jdbc:', ''))
            host = parsed_url.hostname
            port = parsed_url.port
            database = parsed_url.path[1:] if parsed_url.path else 'unknown'
            
            # Проверка
            if (host == test_case['expected_host'] and 
                port == test_case['expected_port'] and 
                database == test_case['expected_db'] and
                connection_string == test_case['expected_jdbc']):
                print(f"   [OK] Парсинг корректен: {host}:{port}/{database}")
            else:
                print(f"   [ERROR] Ошибка парсинга")
                print(f"      Ожидалось: {test_case['expected_host']}:{test_case['expected_port']}/{test_case['expected_db']}")
                print(f"      Получено: {host}:{port}/{database}")
                
        except Exception as e:
            print(f"   [ERROR] ИСКЛЮЧЕНИЕ: {str(e)}")


def main():
    """Основная функция тестирования"""
    print("ТЕСТИРОВАНИЕ ГИБКОЙ ВАЛИДАЦИИ СТРОК ПОДКЛЮЧЕНИЯ")
    print("=" * 80)
    
    try:
        # Запуск тестов
        validation_results = test_flexible_connection_validation()
        test_postgresql_parsing()
        
        # Сводка результатов
        print("\n" + "=" * 80)
        print("СВОДКА РЕЗУЛЬТАТОВ")
        print("=" * 80)
        
        successful_tests = sum(1 for r in validation_results if r.get('success', False))
        total_tests = len(validation_results)
        
        print(f"[OK] Успешных тестов: {successful_tests} из {total_tests}")
        print(f"Процент успеха: {(successful_tests/total_tests)*100:.1f}%")
        
        if successful_tests == total_tests:
            print("ВСЕ ТЕСТЫ ПРОЙДЕНЫ УСПЕШНО!")
        else:
            print("Некоторые тесты не прошли проверку")
            
            print("\nДетали:")
            for result in validation_results:
                status = "[OK]" if result.get('success', False) else "[ERROR]"
                print(f"   {status} {result['name']}")
        
        print("\n" + "=" * 80)
        print("ОСНОВНЫЕ УЛУЧШЕНИЯ:")
        print("=" * 80)
        print("[OK] 1. Гибкая валидация строк подключения (поддержка обычных URL)")
        print("[OK] 2. Автоматическое добавление JDBC префиксов")
        print("[OK] 3. Специальная обработка Oracle thin driver")
        print("[OK] 4. Улучшенная диагностика и преобразования")
        print("[OK] 5. Обратная совместимость с существующими JDBC URL")
        
        print(f"\nТеперь строка '{'postgresql://172.24.86.249:5434/airflow'}' должна работать!")
        
        return successful_tests == total_tests
        
    except Exception as e:
        print(f"[ERROR] КРИТИЧЕСКАЯ ОШИБКА: {str(e)}")
        return False


if __name__ == '__main__':
    success = main()
    exit(0 if success else 1)