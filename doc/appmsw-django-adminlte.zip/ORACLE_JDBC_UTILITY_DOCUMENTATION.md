# Oracle JDBC Utility - Документация

## Обзор

Файл `appmsw/jdbc_util.py` содержит универсальные функции для работы с Oracle Database через JDBC. Утилита предоставляет удобный интерфейс для подключения к Oracle и выполнения SQL запросов.

## Основные компоненты

### Класс OracleJDBCUtil

Основной класс для работы с Oracle через JDBC.

#### Инициализация

```python
oracle_util = OracleJDBCUtil(jar_path='appmsw/java/ojdbc6.jar')
```

#### Основные методы

**connect(url, username, password)**
- Подключение к Oracle database
- Возвращает `True` при успехе, `False` при ошибке

**execute_query(sql_query)**
- Выполнение SELECT запроса
- Возвращает список результатов или `None` при ошибке

**execute_update(sql_query)**
- Выполнение INSERT/UPDATE/DELETE запроса
- Возвращает количество измененных строк или `-1` при ошибке

**get_column_names()**
- Получение имен колонок последнего запроса
- Возвращает список имен или `None`

**close()**
- Закрытие всех ресурсов и отключение

### Удобные функции

**execute_oracle_query(url, username, password, sql_query)**
```python
column_names, results = execute_oracle_query(
    url, username, password, sql_query
)
```

**test_oracle_connection(url, username, password)**
```python
if test_oracle_connection(url, username, password):
    print("Подключение успешно!")
```

## Примеры использования

### 1. Использование контекстного менеджера (рекомендуется)

```python
from appmsw.jdbc_util import OracleJDBCUtil

# Подключение и выполнение запроса
with OracleJDBCUtil() as oracle_util:
    if oracle_util.connect('jdbc:oracle:thin:@localhost:1521:xe', 'user', 'pass'):
        results = oracle_util.execute_query('SELECT * FROM employees')
        columns = oracle_util.get_column_names()
        
        if results:
            print("Колонки:", columns)
            for row in results:
                print(row)
```

### 2. Использование удобной функции

```python
from appmsw.jdbc_util import execute_oracle_query

column_names, results = execute_oracle_query(
    'jdbc:oracle:thin:@localhost:1521:xe',
    'user',
    'pass',
    'SELECT name, salary FROM employees WHERE department = IT'
)

if results:
    print("Колонки:", column_names)
    for row in results:
        print(f"Имя: {row[0]}, Зарплата: {row[1]}")
```

### 3. Тестирование подключения

```python
from appmsw.jdbc_util import test_oracle_connection

if test_oracle_connection('jdbc:oracle:thin:@localhost:1521:xe', 'user', 'pass'):
    print("Подключение к Oracle успешно!")
else:
    print("Ошибка подключения к Oracle")
```

## Конфигурация подключения

### JDBC URL форматы для Oracle

1. **Thin драйвер (самый распространенный)**
   ```
   jdbc:oracle:thin:@host:port:service_name
   jdbc:oracle:thin:@//host:port/service_name
   ```

2. **OCI драйвер**
   ```
   jdbc:oracle:oci:@service_name
   ```

3. **Примеры**
   ```python
   # Локальная Oracle XE
   url = 'jdbc:oracle:thin:@localhost:1521:xe'
   
   # С Service Name
   url = 'jdbc:oracle:thin:@myserver:1521:ORCL'
   
   # С использованием TNS
   url = 'jdbc:oracle:thin:@TNS_ALIAS'
   ```

## Обработка ошибок

Все методы возвращают `None` или `False` при ошибке, а также выводят сообщение об ошибке в консоль.

```python
results = oracle_util.execute_query('SELECT * FROM invalid_table')
if results is None:
    print("Произошла ошибка при выполнении запроса")
```

## Лучшие практики

1. **Всегда используйте контекстный менеджер** для автоматического закрытия ресурсов
2. **Обрабатывайте ошибки** проверяя возвращаемые значения
3. **Используйте параметризованные запросы** для безопасности
4. **Закрывайте соединения** после использования

## Интеграция с Django

Файл можно импортировать в любом месте Django проекта:

```python
from appmsw.jdbc_util import execute_oracle_query

def my_view(request):
    columns, results = execute_oracle_query(
        'jdbc:oracle:thin:@localhost:1521:xe',
        'my_user',
        'my_password',
        'SELECT * FROM my_table'
    )
    
    # Использование результатов...
    return render(request, 'template.html', {'data': results})
```

## Зависимости

- jpype (JPype для запуска Java из Python)
- Oracle JDBC драйвер (ojdbc6.jar или ojdbc8.jar)
- Django (для интеграции в Django проект)