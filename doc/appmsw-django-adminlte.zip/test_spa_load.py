#!/usr/bin/env python3
"""
Тест функциональности SPA страницы и DbQueries компонента
"""

import os
import sys
import django

# Настройка Django
sys.path.append(os.getcwd())
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'core.settings')
django.setup()

from django.test import Client
from django.contrib.auth.models import User
from django.urls import reverse

def test_spa_page():
    """Тест SPA страницы"""
    print("=== ТЕСТ SPA СТРАНИЦЫ ===")
    
    # Создаем клиента
    client = Client()
    
    # Создаем пользователя для теста
    if not User.objects.filter(username='testuser').exists():
        user = User.objects.create_user('testuser', 'test@example.com', 'testpass123')
        user.is_staff = True
        user.save()
        print(f"✓ Создан пользователь: {user.username}")
    
    # Логинимся
    client.login(username='testuser', password='testpass123')
    print("✓ Пользователь авторизован")
    
    # Тестируем URL
    response = client.get('/my-spa-page/')
    print(f"✓ Response status: {response.status_code}")
    print(f"✓ Content length: {len(response.content)} bytes")
    
    # Проверяем контент
    if b'DbQueries' in response.content:
        print("✓ SPA контент содержит DbQueries компонент")
    else:
        print("✗ SPA контент не содержит DbQueries компонент")
    
    if b'static/spa/assets/' in response.content:
        print("✓ SPA контент содержит ссылки на статические файлы")
    else:
        print("✗ SPA контент не содержит ссылки на статические файлы")
    
    return response.status_code == 200 and len(response.content) > 1000

def test_db_queries_api():
    """Тест API эндпоинта для запросов к БД"""
    print("\n=== ТЕСТ API ДБ ЗАПРОСОВ ===")
    
    from core.views import db_queries_api
    
    # Создаем тестовый POST запрос
    test_data = {'query': 'SELECT 1 as test_value'}
    
    # Создаем пользователя
    if not User.objects.filter(username='api_testuser').exists():
        user = User.objects.create_user('api_testuser', 'api@example.com', 'apipass123')
        user.is_staff = True
        user.save()
        print(f"✓ Создан API пользователь: {user.username}")
    
    # Создаем клиента и логинимся
    client = Client()
    client.login(username='api_testuser', password='apipass123')
    
    try:
        response = client.post('/api/db-queries/', test_data, content_type='application/json')
        print(f"✓ API Response status: {response.status_code}")
        
        if response.status_code == 200:
            data = response.json()
            print(f"✓ API Response data: {data}")
            return True
        else:
            print(f"✗ API Error: {response.content.decode()}")
            return False
    except Exception as e:
        print(f"✗ API Exception: {e}")
        return False

def test_vue_component():
    """Проверка Vue компонента DbQueries"""
    print("\n=== ТЕСТ VUE КОМПОНЕНТА ===")
    
    vue_file = 'spa/src/views/DbQueries.vue'
    if os.path.exists(vue_file):
        with open(vue_file, 'r', encoding='utf-8') as f:
            content = f.read()
            
        checks = [
            ('<template>', 'Template section'),
            ('sqlQuery', 'SQL query property'),
            ('executeQuery', 'executeQuery method'),
            ('/api/db-queries/', 'API endpoint reference'),
            ('data:', 'Data section'),
            ('methods:', 'Methods section'),
            ('mounted()', 'Mounted lifecycle'),
        ]
        
        for pattern, description in checks:
            if pattern in content:
                print(f"✓ {description} found")
            else:
                print(f"✗ {description} missing")
        
        return True
    else:
        print(f"✗ Vue component file not found: {vue_file}")
        return False

def main():
    """Главная функция тестирования"""
    print("Начинаем тестирование SPA функциональности...\n")
    
    spa_ok = test_spa_page()
    api_ok = test_db_queries_api()
    vue_ok = test_vue_component()
    
    print(f"\n=== РЕЗУЛЬТАТЫ ТЕСТИРОВАНИЯ ===")
    print(f"SPA страница: {'✓ PASS' if spa_ok else '✗ FAIL'}")
    print(f"API эндпоинт: {'✓ PASS' if api_ok else '✗ FAIL'}")
    print(f"Vue компонент: {'✓ PASS' if vue_ok else '✗ FAIL'}")
    
    if spa_ok and api_ok and vue_ok:
        print("\n🎉 ВСЕ ТЕСТЫ ПРОЙДЕНЫ УСПЕШНО!")
        print("Система готова к работе:")
        print("1. Откройте http://localhost:8000/")
        print("2. Войдите в систему (adm/adm)")
        print("3. Нажмите 'SPA' в боковом меню")
        print("4. Форма запросов к БД загрузится автоматически")
    else:
        print("\n⚠️  ОБНАРУЖЕНЫ ПРОБЛЕМЫ - требуется дополнительная настройка")

if __name__ == '__main__':
    main()