# oracle_query_test.py
import os
import subprocess
import sys
import json

def test_oracle_connection_with_queries():
    """Простой тест подключения с выполнением запросов"""
    
    jar_path = r"appmsw/java/ojdbc6.jar"
    
    if not os.path.exists(jar_path):
        print(f"✗ Файл {jar_path} не найден")
        return False
    
    # Тест через subprocess для изоляции JVM
    test_code = '''
import jpype
import jaydebeapi
import sys
import json

jar_path = r"{jar_path}"
jdbc_url = "{jdbc_url}"
username = "{username}"
password = "{password}"

results = {{}}

try:
    jpype.startJVM(classpath=[jar_path])
    results["jvm_started"] = True
    
    # Пробуем разные драйверы
    drivers = ['oracle.jdbc.OracleDriver', 'oracle.jdbc.driver.OracleDriver']
    
    working_driver = None
    conn = None
    
    for driver in drivers:
        try:
            conn = jaydebeapi.connect(driver, jdbc_url, [username, password], jar_path)
            results["connection"] = {{
                "driver": driver,
                "status": "success",
                "url": jdbc_url
            }}
            working_driver = driver
            break
        except Exception as e:
            print(f"DEBUG: Failed with {{driver}}: {{str(e)[:100]}}")
            continue
    
    if not working_driver:
        results["connection"] = {{
            "status": "failed",
            "error": "No working driver found"
        }}
        print("ALL_DRIVERS_FAILED")
        jpype.shutdownJVM()
        sys.exit(1)
    
    # ===== ВЫПОЛНЕНИЕ ЗАПРОСОВ =====
    cursor = conn.cursor()
    query_results = []
    
    # 1. Простой тестовый запрос
    try:
        cursor.execute("SELECT 'Тест подключения успешен!' as message, 1 as code FROM dual")
        row = cursor.fetchone()
        query_results.append({{
            "query": "SELECT 'Тест подключения успешен!' FROM dual",
            "result": {{
                "message": row[0],
                "code": int(row[1])
            }},
            "status": "success"
        }})
    except Exception as e:
        query_results.append({{
            "query": "SELECT 'Тест подключения успешен!' FROM dual",
            "error": str(e),
            "status": "failed"
        }})
    
    # 2. Получение версии Oracle
    try:
        cursor.execute("SELECT banner FROM v$version WHERE banner LIKE 'Oracle%'")
        row = cursor.fetchone()
        if row:
            query_results.append({{
                "query": "SELECT banner FROM v$version WHERE banner LIKE 'Oracle%'",
                "result": {{
                    "oracle_version": row[0]
                }},
                "status": "success"
            }})
        else:
            query_results.append({{
                "query": "SELECT banner FROM v$version WHERE banner LIKE 'Oracle%'",
                "result": "No version info found",
                "status": "warning"
            }})
    except Exception as e:
        query_results.append({{
            "query": "SELECT banner FROM v$version WHERE banner LIKE 'Oracle%'",
            "error": str(e),
            "status": "failed"
        }})
    
    # 3. Получение информации об инстансе
    try:
        cursor.execute("""
            SELECT 
                instance_name,
                host_name,
                version,
                TO_CHAR(startup_time, 'DD.MM.YYYY HH24:MI:SS') as startup_time,
                status
            FROM v$instance
        """)
        row = cursor.fetchone()
        if row:
            query_results.append({{
                "query": "SELECT * FROM v$instance",
                "result": {{
                    "instance_name": row[0],
                    "host_name": row[1],
                    "version": row[2],
                    "startup_time": row[3],
                    "status": row[4]
                }},
                "status": "success"
            }})
    except Exception as e:
        query_results.append({{
            "query": "SELECT * FROM v$instance",
            "error": str(e),
            "status": "failed"
        }})
    
    # 4. Получение текущей даты и времени
    try:
        cursor.execute("""
            SELECT 
                TO_CHAR(SYSDATE, 'DD.MM.YYYY HH24:MI:SS') as current_date,
                TO_CHAR(SYSTIMESTAMP, 'DD.MM.YYYY HH24:MI:SS.FF3') as current_timestamp
            FROM dual
        """)
        row = cursor.fetchone()
        query_results.append({{
            "query": "SELECT SYSDATE, SYSTIMESTAMP FROM dual",
            "result": {{
                "current_date": row[0],
                "current_timestamp": row[1]
            }},
            "status": "success"
        }})
    except Exception as e:
        query_results.append({{
            "query": "SELECT SYSDATE, SYSTIMESTAMP FROM dual",
            "error": str(e),
            "status": "failed"
        }})
    
    # 5. Получение информации о текущем пользователе
    try:
        cursor.execute("""
            SELECT 
                user as current_user,
                sys_context('USERENV', 'CURRENT_SCHEMA') as current_schema,
                sys_context('USERENV', 'SESSIONID') as session_id,
                sys_context('USERENV', 'DB_NAME') as database_name
            FROM dual
        """)
        row = cursor.fetchone()
        query_results.append({{
            "query": "SELECT user information",
            "result": {{
                "current_user": row[0],
                "current_schema": row[1],
                "session_id": row[2],
                "database_name": row[3]
            }},
            "status": "success"
        }})
    except Exception as e:
        query_results.append({{
            "query": "SELECT user information",
            "error": str(e),
            "status": "failed"
        }})
    
    # 6. Получение количества таблиц в схеме пользователя
    try:
        cursor.execute("SELECT COUNT(*) as table_count FROM user_tables")
        row = cursor.fetchone()
        query_results.append({{
            "query": "SELECT COUNT(*) FROM user_tables",
            "result": {{
                "table_count": int(row[0])
            }},
            "status": "success"
        }})
        
        # Если таблиц немного, покажем их список
        if int(row[0]) <= 20 and int(row[0]) > 0:
            cursor.execute("""
                SELECT table_name, num_rows 
                FROM user_tables 
                WHERE rownum <= 10 
                ORDER BY table_name
            """)
            tables = cursor.fetchall()
            table_list = []
            for table in tables:
                table_list.append({{
                    "table_name": table[0],
                    "num_rows": table[1] if table[1] else "N/A"
                }})
            
            query_results.append({{
                "query": "SELECT table_name FROM user_tables (первые 10)",
                "result": {{
                    "tables": table_list
                }},
                "status": "success"
            }})
    except Exception as e:
        query_results.append({{
            "query": "SELECT COUNT(*) FROM user_tables",
            "error": str(e),
            "status": "failed"
        }})
    
    # 7. Пользовательские запросы (можно добавить свои)
    custom_queries = {custom_queries}
    
    for i, custom_query in enumerate(custom_queries, 1):
        try:
            cursor.execute(custom_query["sql"])
            
            # Проверяем, является ли запрос SELECT
            if custom_query["sql"].strip().upper().startswith("SELECT"):
                rows = cursor.fetchall()
                
                # Если много строк, покажем только первые несколько
                if len(rows) > 10:
                    result_rows = rows[:5]
                    result_info = {{
                        "total_rows": len(rows),
                        "showing_first": 5,
                        "data": result_rows
                    }}
                else:
                    result_info = {{
                        "total_rows": len(rows),
                        "data": rows
                    }}
                
                # Получаем имена колонок
                column_names = [desc[0] for desc in cursor.description]
                result_info["columns"] = column_names
                
                query_results.append({{
                    "query": custom_query["name"],
                    "sql": custom_query["sql"],
                    "result": result_info,
                    "status": "success"
                }})
            else:
                # Для не-SELECT запросов
                query_results.append({{
                    "query": custom_query["name"],
                    "sql": custom_query["sql"],
                    "result": {{
                        "rows_affected": cursor.rowcount,
                        "message": "Query executed successfully"
                    }},
                    "status": "success"
                }})
                
        except Exception as e:
            query_results.append({{
                "query": custom_query["name"],
                "sql": custom_query["sql"],
                "error": str(e),
                "status": "failed"
            }})
    
    cursor.close()
    conn.close()
    
    results["queries"] = query_results
    
    # Выводим результаты в формате JSON
    print(json.dumps(results, indent=2, ensure_ascii=False))
    
    jpype.shutdownJVM()
    sys.exit(0)
    
except Exception as e:
    results["error"] = str(e)
    results["status"] = "jvm_error"
    print(json.dumps(results, indent=2, ensure_ascii=False))
    sys.exit(2)
'''.format(
        jar_path=jar_path,
        jdbc_url="jdbc:oracle:thin:@(DESCRIPTION =   (ADDRESS = (PROTOCOL = TCP)(HOST = hr7-scan1.mvk.ru)(PORT = 1521))  (CONNECT_DATA =        (SERVER = DEDICATED)        (SERVICE_NAME = EBSDEV)      )    )",
        username="is_kip",
        password="is_kip",  # Замените на реальный пароль
        custom_queries=[
            {
                "name": "Проверка системных таблиц",
                "sql": "SELECT table_name FROM all_tables WHERE owner = USER AND rownum <= 5"
            },
            {
                "name": "Размер БД",
                "sql": "SELECT SUM(bytes)/1024/1024 as size_mb FROM user_segments"
            }
        ]
    )
    
    print("="*60)
    print("ТЕСТ ПОДКЛЮЧЕНИЯ К ORACLE С ВЫПОЛНЕНИЕМ ЗАПРОСОВ")
    print("="*60)
    
    # Запускаем в отдельном процессе
    result = subprocess.run(
        [sys.executable, "-c", test_code],
        capture_output=True,
        text=True,
        encoding='utf-8'
    )
    
    print("\n📊 РЕЗУЛЬТАТЫ ТЕСТА:")
    print("-"*60)
    
    if result.returncode == 0:
        try:
            # Парсим JSON вывод
            data = json.loads(result.stdout)
            
            # Выводим информацию о подключении
            if "connection" in data:
                conn_info = data["connection"]
                if conn_info["status"] == "success":
                    print(f"✅ Подключение успешно!")
                    print(f"   Драйвер: {conn_info['driver']}")
                    print(f"   URL: {conn_info['url']}")
                else:
                    print(f"❌ Ошибка подключения: {conn_info.get('error', 'Unknown error')}")
            
            # Выводим результаты запросов
            if "queries" in data:
                print(f"\n📋 Результаты запросов ({len(data['queries'])}):")
                print("-"*40)
                
                for i, query_result in enumerate(data["queries"], 1):
                    status_icon = "✅" if query_result["status"] == "success" else "⚠️" if query_result["status"] == "warning" else "❌"
                    print(f"{i}. {status_icon} {query_result['query']}")
                    
                    if query_result["status"] == "success" and "result" in query_result:
                        result_data = query_result["result"]
                        
                        if isinstance(result_data, dict):
                            for key, value in result_data.items():
                                if key == "data" and isinstance(value, list):
                                    print(f"   Данные ({len(value)} строк):")
                                    for row in value[:3]:  # Показываем первые 3 строки
                                        print(f"     {row}")
                                    if len(value) > 3:
                                        print(f"     ... и еще {len(value) - 3} строк")
                                elif key == "tables" and isinstance(value, list):
                                    print(f"   Таблицы ({len(value)}):")
                                    for table in value:
                                        print(f"     • {table['table_name']} (строк: {table['num_rows']})")
                                else:
                                    print(f"   {key}: {value}")
                        else:
                            print(f"   Результат: {result_data}")
                    
                    elif query_result["status"] == "failed":
                        print(f"   Ошибка: {query_result.get('error', 'Unknown error')}")
                    
                    print()
            
            return True
            
        except json.JSONDecodeError:
            print("Ошибка парсинга JSON вывода:")
            print(result.stdout)
            return False
    
    else:
        print("❌ Тест завершился с ошибкой")
        print(f"Код возврата: {result.returncode}")
        
        if result.stdout:
            print("\nВывод программы:")
            print(result.stdout)
        
        if result.stderr:
            print("\nОшибки:")
            print(result.stderr)
        
        return False

def interactive_test():
    """Интерактивный тест с пользовательскими запросами"""
    
    jar_path = r"d:\java\ojdbc6.jar"
    
    if not os.path.exists(jar_path):
        print(f"✗ Файл {jar_path} не найден")
        return False
    
    print("\n" + "="*60)
    print("ИНТЕРАКТИВНЫЙ ТЕСТ ORACLE")
    print("="*60)
    
    # Запрашиваем параметры подключения
    jdbc_url = input("Введите JDBC URL [jdbc:oracle:thin:@localhost:1521:EBS]: ").strip()
    if not jdbc_url:
        jdbc_url = "jdbc:oracle:thin:@localhost:1521:EBS"
    
    username = input("Введите имя пользователя [user]: ").strip()
    if not username:
        username = "user"
    
    password = input("Введите пароль: ").strip()
    
    # Запрашиваем пользовательские запросы
    custom_queries = []
    print("\nВведите SQL запросы (оставьте пустую строку для завершения):")
    
    while True:
        query_name = input("\nНазвание запроса (например: 'Проверка пользователей'): ").strip()
        if not query_name:
            break
            
        sql = input("SQL запрос: ").strip()
        if not sql:
            print("Запрос не может быть пустым")
            continue
            
        custom_queries.append({
            "name": query_name,
            "sql": sql
        })
        
        more = input("Добавить еще запрос? (y/n): ").strip().lower()
        if more != 'y':
            break
    
    # Тест через subprocess
    test_code = '''
import jpype
import jaydebeapi
import sys
import json

jar_path = r"{jar_path}"
jdbc_url = "{jdbc_url}"
username = "{username}"
password = "{password}"
custom_queries = {custom_queries}

try:
    jpype.startJVM(classpath=[jar_path])
    
    conn = jaydebeapi.connect('oracle.jdbc.OracleDriver', jdbc_url, [username, password], jar_path)
    cursor = conn.cursor()
    
    results = {{}}
    query_results = []
    
    for custom_query in custom_queries:
        try:
            print(f"\\n▶ Выполняю: {{custom_query['name']}}")
            print(f"   SQL: {{custom_query['sql']}}")
            
            cursor.execute(custom_query["sql"])
            
            if custom_query["sql"].strip().upper().startswith("SELECT"):
                # Получаем имена колонок
                columns = [desc[0] for desc in cursor.description]
                
                # Получаем данные
                rows = cursor.fetchall()
                
                # Формируем результат
                formatted_rows = []
                for row in rows:
                    formatted_row = {{}}
                    for i, col in enumerate(columns):
                        formatted_row[col] = str(row[i]) if row[i] is not None else "NULL"
                    formatted_rows.append(formatted_row)
                
                result = {{
                    "columns": columns,
                    "rows": formatted_rows,
                    "row_count": len(rows)
                }}
                
                query_results.append({{
                    "name": custom_query["name"],
                    "sql": custom_query["sql"],
                    "status": "success",
                    "result": result
                }})
                
                # Выводим результаты сразу
                print(f"   ✅ Успешно! Найдено строк: {{len(rows)}}")
                if len(rows) > 0:
                    print("   Первые строки:")
                    for i, row in enumerate(formatted_rows[:3], 1):
                        print(f"     {{i}}. {{row}}")
                    if len(rows) > 3:
                        print(f"     ... и еще {{len(rows) - 3}} строк")
                        
            else:
                # Для не-SELECT запросов
                rowcount = cursor.rowcount
                result = {{
                    "rows_affected": rowcount,
                    "message": "Query executed successfully"
                }}
                
                query_results.append({{
                    "name": custom_query["name"],
                    "sql": custom_query["sql"],
                    "status": "success",
                    "result": result
                }})
                
                print(f"   ✅ Успешно! Затронуто строк: {{rowcount}}")
                
        except Exception as e:
            error_msg = str(e)
            query_results.append({{
                "name": custom_query["name"],
                "sql": custom_query["sql"],
                "status": "failed",
                "error": error_msg
            }})
            
            print(f"   ❌ Ошибка: {{error_msg[:100]}}")
    
    cursor.close()
    conn.close()
    jpype.shutdownJVM()
    
    # Сохраняем результаты в файл
    with open("oracle_query_results.json", "w", encoding="utf-8") as f:
        json.dump({{
            "connection": {{
                "url": jdbc_url,
                "username": username,
                "status": "success"
            }},
            "queries": query_results
        }}, f, indent=2, ensure_ascii=False, default=str)
    
    print(f"\\n💾 Результаты сохранены в oracle_query_results.json")
    
except Exception as e:
    print(f"❌ Критическая ошибка: {{e}}")
    jpype.shutdownJVM()
    sys.exit(1)
'''.format(
        jar_path=jar_path,
        jdbc_url=jdbc_url,
        username=username,
        password=password,
        custom_queries=json.dumps(custom_queries, ensure_ascii=False)
    )
    
    # Запускаем тест
    result = subprocess.run(
        [sys.executable, "-c", test_code],
        capture_output=True,
        text=True,
        encoding='utf-8'
    )
    
    print("\n" + "="*60)
    print("РЕЗУЛЬТАТ ВЫПОЛНЕНИЯ:")
    print("="*60)
    
    if result.stdout:
        print(result.stdout)
    
    if result.stderr:
        print("\nОШИБКИ:")
        print(result.stderr)
    
    return result.returncode == 0

if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description='Тестирование подключения к Oracle')
    parser.add_argument('--interactive', '-i', action='store_true', help='Интерактивный режим')
    parser.add_argument('--quick', '-q', action='store_true', help='Быстрый тест')
    
    args = parser.parse_args()
    
    if args.interactive:
        interactive_test()
    else:
        test_oracle_connection_with_queries()