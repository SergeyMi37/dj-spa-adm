#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Простой тест JDBC подключения и выполнения запросов к IRIS
"""

import jaydebeapi
import sys
import os

def test_iris_jdbc():
    """Тест JDBC подключения к IRIS"""
    print("=" * 80)
    print("ТЕСТ JDBC ПОДКЛЮЧЕНИЯ К IRIS")
    print("=" * 80)
    
    # Конфигурация подключения (измените под вашу среду)
    # jdbc:IRIS://172.24.86.249:51443/USER
    config = {
        'host': '172.24.86.249',
        'port': '51443',
        'namespace': 'USER',
        'username': 'superuser',
        'password': 'SYS'
    }
    
    # JAR файлы для IRIS (несколько вариантов для fallback)
    iris_jar_sets = [
        ['appmsw/java/intersystems-jdbc-3.10.2.jar'],
        ['appmsw/java/intersystems-jdbc-3.1.0.jar'],
        ['appmsw/java/intersystems-jdbc-3.2.0.jar'],
        ['appmsw/java/intersystems-jdbc-3.3.0.jar'],
        ['appmsw/java/intersystems-jdbc-3.7.1.jar'],
        ['appmsw/java/intersystems-jdbc-3.8.4.jar'],
        ['appmsw/java/intersystems-jdbc-3.9.0.jar']
    ]
    
    # Имена драйверов для IRIS (несколько вариантов для fallback)
    iris_drivers = [
        'com.intersystems.jdbc.IRISDriver',
        'com.intersystems.jdbc.CacheDriver'
    ]
    
    # JDBC URL для IRIS
    jdbc_url = f"jdbc:IRIS://{config['host']}:{config['port']}/{config['namespace']}"
    
    print(f"JDBC URL: {jdbc_url}")
    print(f"Username: {config['username']}")
    print(f"Namespace: {config['namespace']}")
    print()
    
    print("JAR файлы (попробуем разные наборы):")
    for i, jar_set in enumerate(iris_jar_sets):
        print(f"  Набор {i+1}: {jar_set}")
    print()
    
    print("Драйверы (попробуем разные):")
    for i, driver in enumerate(iris_drivers):
        print(f"  {i+1}. {driver}")
    print()
    
    # Пробуем разные комбинации JAR файлов и драйверов
    connection = None
    last_error = None
    
    for jar_idx, jar_set in enumerate(iris_jar_sets):
        # Проверяем наличие всех JAR файлов в наборе
        missing_jars = []
        for jar_path in jar_set:
            if not os.path.exists(jar_path):
                missing_jars.append(jar_path)
        
        if missing_jars:
            print(f"❌ Набор JAR {jar_idx+1}: отсутствуют файлы {missing_jars}")
            continue
        
        print(f"✓ Набор JAR {jar_idx+1}: все файлы найдены")
        
        for driver_idx, driver_class in enumerate(iris_drivers):
            try:
                print(f"\nПопытка подключения:")
                print(f"  JAR набор: {jar_idx+1}")
                print(f"  Драйвер: {driver_idx+1} ({driver_class})")
                print(f"  JDBC URL: {jdbc_url}")
                
                connection = jaydebeapi.connect(
                    driver_class,
                    jdbc_url,
                    [config['username'], config['password']],
                    jars=[jar_set]
                )
                
                print(f"✓ Подключение к IRIS успешно установлено!")
                print(f"  Использован JAR набор {jar_idx+1}")
                print(f"  Использован драйвер {driver_idx+1}")
                break
                
            except Exception as e:
                error_msg = str(e)
                print(f"❌ Неудача с JAR набором {jar_idx+1} и драйвером {driver_idx+1}:")
                print(f"   {error_msg[:100]}...")
                last_error = e
                connection = None
                continue
        
        if connection:
            break
    
    if connection is None:
        print(f"\n❌ Не удалось подключиться к IRIS ни с одной комбинацией")
        print("\nВозможные причины:")
        print("1. IRIS сервер не запущен")
        print("2. Неверные параметры подключения")
        print("3. Недостаточные права доступа")
        print("4. JDBC драйверы недоступны или несовместимы")
        print("5. Неправильный namespace")
        return False
    
    try:
        # Выполняем тестовый запрос
        cursor = connection.cursor()
        test_query = "SELECT 1 as test_value, 'IRIS JDBC Test' as message"
        
        print(f"\nВыполнение запроса: {test_query}")
        cursor.execute(test_query)
        
        # Получаем результат
        result = cursor.fetchone()
        print(f"✓ Результат: {result}")
        
        # Выполняем запрос к системным таблицам IRIS
        system_query = "SELECT $VERSION"
        print(f"\nВыполнение системного запроса: {system_query}")
        cursor.execute(system_query)
        
        version_result = cursor.fetchone()
        print(f"✓ Версия IRIS: {version_result[0] if version_result else 'Не удалось получить'}")
        
        # Проверяем информацию о подключении
        info_query = "SELECT $USERNAME, $NAMESPACE"
        print(f"\nВыполнение запроса: {info_query}")
        cursor.execute(info_query)
        
        info_result = cursor.fetchone()
        if info_result:
            print(f"✓ Пользователь: {info_result[0]}")
            print(f"✓ Namespace: {info_result[1]}")
        
        # Проверяем наличие таблиц в namespace
        tables_query = "SELECT Name FROM %Library.SQLCatalog WHERE TableType='TABLE'"
        print(f"\nВыполнение запроса таблиц (первые 5): {tables_query}")
        cursor.execute(tables_query)
        
        tables_result = cursor.fetchmany(5)
        if tables_result:
            print("✓ Таблицы в namespace:")
            for row in tables_result:
                print(f"   - {row[0]}")
        else:
            print("ℹ️  Таблицы не найдены или нет доступа к системным таблицам")
        
        # Закрываем подключение
        connection.close()
        print("\n✓ Подключение закрыто")
        
        return True
        
    except Exception as e:
        print(f"\n❌ Ошибка выполнения запросов к IRIS: {str(e)}")
        return False

def test_iris_connection_info():
    """Дополнительная информация о настройке подключения IRIS"""
    print("\n" + "=" * 80)
    print("ИНФОРМАЦИЯ О НАСТРОЙКЕ IRIS JDBC")
    print("=" * 80)
    
    print("Для успешного тестирования настройте следующие параметры:")
    print()
    print("1. IRIS сервер должен быть запущен")
    print("2. Убедитесь, что JDBC драйверы доступны:")
    
    # Проверяем наличие JAR файлов
    jar_files = [
        "appmsw/java/intersystems-jdbc-3.10.2.jar",
    ]
    
    for jar_path in jar_files:
        if os.path.exists(jar_path):
            print(f"   ✓ {jar_path}")
        else:
            print(f"   ❌ {jar_path} - файл не найден")
    
    print("\n3. Примеры строк подключения IRIS:")
    examples = [
        "jdbc:IRIS://localhost:1972/USER",
    ]
    for example in examples:
        print(f"   {example}")
    
    print("\n4. Форматы JDBC URL для IRIS:")
    print("   jdbc:IRIS://host:port/NAMESPACE")
    print("   jdbc:cache://host:port/NAMESPACE (для Cache)")
    
    print("\n5. Требования к пользователю:")
    print("   - Пользователь должен существовать в IRIS")
    print("   - У пользователя должны быть права на подключение к namespace")
    print("   - Namespace должен существовать и быть доступным")
    
    print("\n6. Команды для проверки IRIS:")
    print("   iris session USER")
    print("   write $VERSION")
    print("   write $USERNAME")
    print("   write $NAMESPACE")

def main():
    """Основная функция"""
    print("ТЕСТИРОВАНИЕ JDBC ПОДКЛЮЧЕНИЯ К IRIS")
    print("Для настройки подключения измените параметры в функции test_iris_jdbc()")
    print()
    
    # Проверяем наличие необходимых модулей
    try:
        import jaydebeapi
        print("✓ Модуль jaydebeapi доступен")
    except ImportError:
        print("❌ Модуль jaydebeapi не найден. Установите: pip install jaydebeapi")
        return False
    
    # Показываем информацию о настройке
    test_iris_connection_info()
    
    # Запрашиваем подтверждение для тестирования
    print("\n" + "=" * 80)
    response = input("Запустить тест подключения к IRIS? (y/N): ")
    
    if response.lower() in ['y', 'yes', 'да', 'д']:
        success = test_iris_jdbc()
        if success:
            print("\n🎉 ТЕСТ IRIS JDBC УСПЕШНО ЗАВЕРШЕН!")
        else:
            print("\n💥 ТЕСТ IRIS JDBC НЕ УДАЛСЯ!")
        return success
    else:
        print("\nТест отменен пользователем")
        return None

if __name__ == '__main__':
    main()