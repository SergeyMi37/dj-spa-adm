# simple_test.py
import os
import subprocess
import sys

def test_oracle_connection():
    """Простой тест подключения"""
    
    jar_path = r"appmsw/java/ojdbc6.jar"
    
    if not os.path.exists(jar_path):
        print(f"✗ Файл {jar_path} не найден")
        return False
    
    # Тест через subprocess для изоляции JVM
    test_code = '''
import jpype
import jaydebeapi
import sys

jar_path = r"{jar_path}"
jdbc_url = "{jdbc_url}"
username = "{username}"
password = "{password}"

try:
    jpype.startJVM(classpath=[jar_path])
    
    # Пробуем разные драйверы
    drivers = ['oracle.jdbc.OracleDriver', 'oracle.jdbc.driver.OracleDriver']
    
    for driver in drivers:
        try:
            conn = jaydebeapi.connect(driver, jdbc_url, [username, password], jar_path)
            cursor = conn.cursor()
            cursor.execute("SELECT 'SUCCESS' FROM dual")
            result = cursor.fetchone()[0]
            print(f"SUCCESS: {{result}} with driver {{driver}}")
            cursor.close()
            conn.close()
            jpype.shutdownJVM()
            sys.exit(0)
        except Exception as e:
            print(f"FAILED with {{driver}}: {{str(e)[:100]}}")
            continue
    
    print("ALL_DRIVERS_FAILED")
    jpype.shutdownJVM()
    sys.exit(1)
    
except Exception as e:
    print(f"JVM_ERROR: {{e}}")
    sys.exit(2)
'''.format(
        jar_path=jar_path,
        jdbc_url="jdbc:oracle:thin:@(DESCRIPTION =   (ADDRESS = (PROTOCOL = TCP)(HOST = hr7-scan1.mvk.ru)(PORT = 1521))  (CONNECT_DATA =        (SERVER = DEDICATED)        (SERVICE_NAME = EBSDEV)      )    )",
        username="is_kip",
        password="is_kip"
    )
    
    # Запускаем в отдельном процессе
    result = subprocess.run(
        [sys.executable, "-c", test_code],
        capture_output=True,
        text=True
    )
    
    print("Вывод теста:")
    print(result.stdout)
    if result.stderr:
        print("Ошибки:")
        print(result.stderr)
    
    return result.returncode == 0

if __name__ == "__main__":
    test_oracle_connection()